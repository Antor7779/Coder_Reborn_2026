import '../models/job_request.dart';

class DemoJobRequests {
  static List<JobRequest> jobRequests = [
    JobRequest(
      id: 1,
      orderNumber: 'JR1001',

      customerId: 1,
      customerName: 'Antor Shardar',
      customerPhone: '01711111111',

      isForAnotherPerson: true,

      recipientName: 'Rahim Uddin',
      recipientPhone: '01722222222',
      recipientAddress:
      'House 15, Road 3, Mirpur 10, Dhaka',
      recipientLatitude: 23.8103,
      recipientLongitude: 90.4125,

      serviceName: 'AC Servicing',
      serviceCategory: 'Home Appliance',
      serviceDescription:
      'General AC servicing and cleaning.',
      servicePrice: 1200,

      bookingDate: DateTime.now().subtract(
        const Duration(minutes: 15),
      ),

      scheduledDate: DateTime.now().add(
        const Duration(hours: 3),
      ),

      assignedWorkerId: null,
      assignedWorkerName: null,

      status: 'Pending',

      notes:
      'Customer booked this service for his father. Please call before arriving.',

      distanceKm: 3.5,

      estimatedArrival: const Duration(
        minutes: 20,
      ),

      extraTimeTaken: Duration.zero,

      eligibleForBonus: true,

      bonusAmount: 100,

      isCompleted: false,

      completedAt: null,
    ),

    JobRequest(
      id: 2,
      orderNumber: 'JR1002',

      customerId: 2,
      customerName: 'Nusrat Jahan',
      customerPhone: '01812345678',

      isForAnotherPerson: false,

      recipientName: 'Nusrat Jahan',
      recipientPhone: '01812345678',
      recipientAddress: 'Banani DOHS, Dhaka',
      recipientLatitude: 23.7937,
      recipientLongitude: 90.4066,

      serviceName: 'Deep Cleaning',
      serviceCategory: 'Cleaning',
      serviceDescription:
      'Complete home deep cleaning service.',
      servicePrice: 2500,

      bookingDate: DateTime.now().subtract(
        const Duration(minutes: 35),
      ),

      scheduledDate: DateTime.now().add(
        const Duration(hours: 6),
      ),

      assignedWorkerId: null,
      assignedWorkerName: null,

      status: 'Pending',

      notes:
      'Customer prefers eco-friendly cleaning products.',

      distanceKm: 5.2,

      estimatedArrival: const Duration(
        minutes: 30,
      ),

      extraTimeTaken: Duration.zero,

      eligibleForBonus: false,

      bonusAmount: 0,

      isCompleted: false,

      completedAt: null,
    ),

    JobRequest(
      id: 3,
      orderNumber: 'JR1003',

      customerId: 3,
      customerName: 'Karim Hasan',
      customerPhone: '01999887766',

      isForAnotherPerson: true,

      recipientName: 'Shamima Begum',
      recipientPhone: '01988776655',
      recipientAddress: 'Gazipur Sadar, Gazipur',
      recipientLatitude: 24.0023,
      recipientLongitude: 90.4266,

      serviceName: 'Plumbing Repair',
      serviceCategory: 'Home Repair',
      serviceDescription:
      'Repair leaking water pipe.',
      servicePrice: 900,

      bookingDate: DateTime.now().subtract(
        const Duration(hours: 1),
      ),

      scheduledDate: DateTime.now().add(
        const Duration(hours: 2),
      ),

      assignedWorkerId: null,
      assignedWorkerName: null,

      status: 'Pending',

      notes:
      'The recipient is elderly. Please explain the repair process clearly.',

      distanceKm: 8.7,

      estimatedArrival: const Duration(
        minutes: 45,
      ),

      extraTimeTaken: Duration.zero,

      eligibleForBonus: true,

      bonusAmount: 150,

      isCompleted: false,

      completedAt: null,
    ),

    JobRequest(
      id: 4,
      orderNumber: 'JR1004',

      customerId: 4,
      customerName: 'Sabbir Ahmed',
      customerPhone: '01677889900',

      isForAnotherPerson: false,

      recipientName: 'Sabbir Ahmed',
      recipientPhone: '01677889900',
      recipientAddress: 'Dhanmondi 27, Dhaka',
      recipientLatitude: 23.7465,
      recipientLongitude: 90.3760,

      serviceName: 'Electrician',
      serviceCategory: 'Electrical',
      serviceDescription:
      'Circuit breaker inspection.',
      servicePrice: 1500,

      bookingDate: DateTime.now().subtract(
        const Duration(minutes: 50),
      ),

      scheduledDate: DateTime.now().add(
        const Duration(hours: 5),
      ),

      assignedWorkerId: null,
      assignedWorkerName: null,

      status: 'Pending',

      notes:
      'Need urgent inspection for circuit breaker issue.',

      distanceKm: 4.1,

      estimatedArrival: const Duration(
        minutes: 25,
      ),

      extraTimeTaken: Duration.zero,

      eligibleForBonus: false,

      bonusAmount: 0,

      isCompleted: false,

      completedAt: null,
    ),

    JobRequest(
      id: 5,
      orderNumber: 'JR1005',

      customerId: 5,
      customerName: 'Fahim Chowdhury',
      customerPhone: '01555667788',

      isForAnotherPerson: true,

      recipientName: 'Rokeya Begum',
      recipientPhone: '01566778899',
      recipientAddress: 'Uttara Sector 7, Dhaka',
      recipientLatitude: 23.8759,
      recipientLongitude: 90.3795,

      serviceName: 'Home Nursing',
      serviceCategory: 'Healthcare',
      serviceDescription:
      'Home nursing care for elderly patient.',
      servicePrice: 3000,

      bookingDate: DateTime.now().subtract(
        const Duration(hours: 2),
      ),

      scheduledDate: DateTime.now().add(
        const Duration(days: 1),
      ),

      assignedWorkerId: null,
      assignedWorkerName: null,

      status: 'Pending',

      notes:
      'Booked for mother. Worker should arrive 30 minutes early.',

      distanceKm: 9.4,

      estimatedArrival: const Duration(
        minutes: 50,
      ),

      extraTimeTaken: Duration.zero,

      eligibleForBonus: true,

      bonusAmount: 200,

      isCompleted: false,

      completedAt: null,
    ),
  ];

  static List<JobRequest> get pendingRequests {
    return jobRequests.where(
          (job) => job.status == 'Pending',
    ).toList();
  }

  static List<JobRequest> get acceptedRequests {
    return jobRequests.where(
          (job) => job.status == 'Accepted',
    ).toList();
  }

  static void acceptJob(int jobId) {
    final index = jobRequests.indexWhere(
          (job) => job.id == jobId,
    );

    if (index == -1) return;

    jobRequests[index] = jobRequests[index]
        .copyWith(
      status: 'Accepted',
    );
  }

  static void rejectJob(int jobId) {
    final index = jobRequests.indexWhere(
          (job) => job.id == jobId,
    );

    if (index == -1) return;

    jobRequests[index] = jobRequests[index]
        .copyWith(
      status: 'Cancelled',
    );
  }

  static JobRequest? getById(int id) {
    try {
      return jobRequests.firstWhere(
            (job) => job.id == id,
      );
    } catch (_) {
      return null;
    }
  }
}