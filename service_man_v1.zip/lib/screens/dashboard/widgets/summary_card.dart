import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class SummaryCard extends StatefulWidget {
  final String title;

  final int value;

  final IconData icon;

  final Color color;

  final VoidCallback? onTap;

  const SummaryCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    this.onTap,
  });

  @override
  State<SummaryCard> createState() =>
      _SummaryCardState();
}

class _SummaryCardState
    extends State<SummaryCard> {
  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 900,
      ),

      curve: Curves.easeOutCubic,

      tween: Tween(
        begin: 0,
        end: widget.value.toDouble(),
      ),

      builder: (
          context,
          animatedValue,
          child,
          ) {
        return Material(
          color: Colors.transparent,

          child: InkWell(
            borderRadius:
            BorderRadius.circular(
              24,
            ),

            onTap: widget.onTap,

            child: Container(
              padding:
              const EdgeInsets.all(
                18,
              ),

              decoration: BoxDecoration(
                color: Colors.white,

                borderRadius:
                BorderRadius.circular(
                  24,
                ),

                boxShadow: [
                  BoxShadow(
                    color: Colors.black
                        .withOpacity(
                      0.05,
                    ),

                    blurRadius: 18,

                    offset:
                    const Offset(
                      0,
                      8,
                    ),
                  ),
                ],
              ),

              child: Column(
                crossAxisAlignment:
                CrossAxisAlignment
                    .start,

                children: [
                  Row(
                    children: [
                      Container(
                        width: 52,

                        height: 52,

                        decoration:
                        BoxDecoration(
                          color: widget
                              .color
                              .withOpacity(
                            0.12,
                          ),

                          borderRadius:
                          BorderRadius
                              .circular(
                            16,
                          ),
                        ),

                        child: Icon(
                          widget.icon,

                          color:
                          widget.color,

                          size: 28,
                        ),
                      ),

                      const Spacer(),

                      Container(
                        width: 8,

                        height: 40,

                        decoration:
                        BoxDecoration(
                          color:
                          widget.color,

                          borderRadius:
                          BorderRadius
                              .circular(
                            20,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 20,
                  ),

                  Text(
                    animatedValue
                        .toInt()
                        .toString(),

                    style:
                    const TextStyle(
                      fontSize: 32,

                      fontWeight:
                      FontWeight
                          .w800,

                      color: AppTheme
                          .textPrimary,
                    ),
                  ),

                  const SizedBox(
                    height: 6,
                  ),

                  Text(
                    widget.title,

                    maxLines: 2,

                    overflow:
                    TextOverflow
                        .ellipsis,

                    style:
                    const TextStyle(
                      fontSize: 14,

                      color: AppTheme
                          .textSecondary,

                      fontWeight:
                      FontWeight
                          .w500,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}