import 'package:flutter/material.dart';

import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/dashboard/dashboard_screen.dart';
import '../screens/earnings/earnings_screen.dart';
import '../screens/jobs/active_jobs_screen.dart';
import '../screens/jobs/pending_jobs_screen.dart';
import '../screens/notifications/notifications_screen.dart';
import '../screens/profile/profile_screen.dart';
import '../widgets/worker_bottom_navigation.dart';

class AppRouter {
  // Route Names
  static const String login =
      '/login';

  static const String register =
      '/register';

  static const String home =
      '/home';

  static const String dashboard =
      '/dashboard';

  static const String pendingJobs =
      '/pending-jobs';

  static const String activeJobs =
      '/active-jobs';

  static const String earnings =
      '/earnings';

  static const String notifications =
      '/notifications';

  static const String profile =
      '/profile';

  static Route<dynamic>
  generateRoute(
      RouteSettings settings,
      ) {
    switch (settings.name) {
      case login:
        return MaterialPageRoute(
          builder:
              (_) =>
          const LoginScreen(),
        );

      case register:
        return MaterialPageRoute(
          builder:
              (_) =>
          const RegisterScreen(),
        );

      case home:
        return MaterialPageRoute(
          builder:
              (_) =>
          const WorkerBottomNavigation(),
        );

      case dashboard:
        return MaterialPageRoute(
          builder:
              (_) =>
          const DashboardScreen(),
        );

      case pendingJobs:
        return MaterialPageRoute(
          builder:
              (_) =>
          const PendingJobsScreen(),
        );

      case activeJobs:
        return MaterialPageRoute(
          builder:
              (_) =>
          const ActiveJobsScreen(),
        );

      case earnings:
        return MaterialPageRoute(
          builder:
              (_) =>
          const EarningsScreen(),
        );

      case notifications:
        return MaterialPageRoute(
          builder:
              (_) => const NotificationsScreen(),
        );

      case profile:
        return MaterialPageRoute(
          builder:
              (_) =>
          const ProfileScreen(),
        );

      default:
        return MaterialPageRoute(
          builder:
              (_) =>
          const _UnknownRouteScreen(),
        );
    }
  }

  // Navigation Helpers

  static Future<dynamic>
  pushNamed(
      BuildContext context,
      String routeName,
      ) {
    return Navigator.pushNamed(
      context,
      routeName,
    );
  }

  static Future<dynamic>
  pushReplacementNamed(
      BuildContext context,
      String routeName,
      ) {
    return Navigator
        .pushReplacementNamed(
      context,
      routeName,
    );
  }

  static Future<dynamic>
  pushNamedAndRemoveUntil(
      BuildContext context,
      String routeName,
      ) {
    return Navigator
        .pushNamedAndRemoveUntil(
      context,
      routeName,
          (route) => false,
    );
  }

  static void pop(
      BuildContext context,
      ) {
    Navigator.pop(
      context,
    );
  }
}

class _UnknownRouteScreen
    extends StatelessWidget {
  const _UnknownRouteScreen();

  @override
  Widget build(
      BuildContext context,
      ) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Page Not Found',
        ),
      ),

      body: Center(
        child: Padding(
          padding:
          const EdgeInsets.all(
            24,
          ),

          child: Column(
            mainAxisAlignment:
            MainAxisAlignment
                .center,

            children: [
              const Icon(
                Icons.error_outline,

                size: 90,

                color: Colors.red,
              ),

              const SizedBox(
                height: 24,
              ),

              const Text(
                'Oops!',

                style: TextStyle(
                  fontSize: 30,

                  fontWeight:
                  FontWeight.bold,
                ),
              ),

              const SizedBox(
                height: 12,
              ),

              const Text(
                'The page you are trying to access does not exist.',

                textAlign:
                TextAlign.center,
              ),

              const SizedBox(
                height: 32,
              ),

              ElevatedButton(
                onPressed: () {
                  AppRouter
                      .pushNamedAndRemoveUntil(
                    context,
                    AppRouter.home,
                  );
                },

                child: const Text(
                  'Go Home',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}