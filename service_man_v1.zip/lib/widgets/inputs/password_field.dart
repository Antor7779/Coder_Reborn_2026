import 'package:flutter/material.dart';

import '../../app/theme.dart';
import 'app_text_field.dart';

class PasswordField extends StatefulWidget {
  final TextEditingController? controller;

  final String label;

  final String hintText;

  final String? Function(String?)? validator;

  final TextInputAction textInputAction;

  final FocusNode? focusNode;

  final ValueChanged<String>? onChanged;

  final bool autofocus;

  const PasswordField({
    super.key,
    this.controller,
    this.label = 'Password',
    this.hintText = 'Enter your password',
    this.validator,
    this.textInputAction = TextInputAction.done,
    this.focusNode,
    this.onChanged,
    this.autofocus = false,
  });

  @override
  State<PasswordField> createState() =>
      _PasswordFieldState();
}

class _PasswordFieldState
    extends State<PasswordField> {
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return AppTextField(
      controller: widget.controller,

      label: widget.label,

      hintText: widget.hintText,

      focusNode: widget.focusNode,

      autofocus: widget.autofocus,

      textInputAction:
      widget.textInputAction,

      obscureText: _obscureText,

      prefixIcon: Icons.lock_outline,

      onChanged: widget.onChanged,

      validator: widget.validator ??
              (value) {
            if (value == null ||
                value.isEmpty) {
              return 'Please enter password';
            }

            if (value.length < 6) {
              return 'Password must be at least 6 characters';
            }

            return null;
          },

      suffixIcon: AnimatedSwitcher(
        duration: const Duration(
          milliseconds: 250,
        ),

        transitionBuilder:
            (
            child,
            animation,
            ) {
          return RotationTransition(
            turns: animation,
            child: FadeTransition(
              opacity: animation,
              child: child,
            ),
          );
        },

        child: IconButton(
          key: ValueKey(
            _obscureText,
          ),

          splashRadius: 22,

          tooltip: _obscureText
              ? 'Show Password'
              : 'Hide Password',

          onPressed: () {
            setState(() {
              _obscureText =
              !_obscureText;
            });
          },

          icon: Icon(
            _obscureText
                ? Icons.visibility_outlined
                : Icons.visibility_off_outlined,

            color:
            AppTheme.textSecondary,
          ),
        ),
      ),
    );
  }
}