import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class PerformanceCard extends StatelessWidget {
  final String currentTier;

  final String nextTier;

  final int currentPoints;

  final int nextTierPoints;

  final double rating;

  const PerformanceCard({
    super.key,
    required this.currentTier,
    required this.nextTier,
    required this.currentPoints,
    required this.nextTierPoints,
    required this.rating,
  });

  Color _getTierColor(String tier) {
    switch (tier.toLowerCase()) {
      case 'bronze':
        return Colors.brown;

      case 'silver':
        return Colors.grey;

      case 'gold':
        return Colors.amber.shade700;

      case 'platinum':
        return Colors.blueGrey;

      default:
        return AppTheme.primaryColor;
    }
  }

  IconData _getTierIcon(String tier) {
    switch (tier.toLowerCase()) {
      case 'bronze':
        return Icons.workspace_premium;

      case 'silver':
        return Icons.military_tech;

      case 'gold':
        return Icons.emoji_events;

      case 'platinum':
        return Icons.diamond;

      default:
        return Icons.star;
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress =
    nextTierPoints <= 0
        ? 1.0
        : (currentPoints / nextTierPoints)
        .clamp(0.0, 1.0);

    final remainingPoints =
    (nextTierPoints - currentPoints)
        .clamp(0, nextTierPoints);

    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 800,
      ),

      curve: Curves.easeOutCubic,

      tween: Tween(
        begin: 0,
        end: progress,
      ),

      builder: (
          context,
          animatedProgress,
          child,
          ) {
        return Container(
          padding: const EdgeInsets.all(
            22,
          ),

          decoration: BoxDecoration(
            color: Colors.white,

            borderRadius:
            BorderRadius.circular(
              28,
            ),

            boxShadow: [
              BoxShadow(
                color: Colors.black
                    .withOpacity(
                  0.05,
                ),

                blurRadius: 18,

                offset: const Offset(
                  0,
                  8,
                ),
              ),
            ],
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment.start,

            children: [
              Row(
                children: [
                  Container(
                    width: 60,

                    height: 60,

                    decoration:
                    BoxDecoration(
                      color: _getTierColor(
                        currentTier,
                      ).withOpacity(
                        0.12,
                      ),

                      borderRadius:
                      BorderRadius
                          .circular(
                        18,
                      ),
                    ),

                    child: Icon(
                      _getTierIcon(
                        currentTier,
                      ),

                      color:
                      _getTierColor(
                        currentTier,
                      ),

                      size: 32,
                    ),
                  ),

                  const SizedBox(
                    width: 16,
                  ),

                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,

                      children: [
                        const Text(
                          'Performance',

                          style: TextStyle(
                            fontSize: 20,

                            fontWeight:
                            FontWeight
                                .bold,

                            color: AppTheme
                                .textPrimary,
                          ),
                        ),

                        const SizedBox(
                          height: 4,
                        ),

                        Text(
                          '$currentTier Partner',

                          style: const TextStyle(
                            color: AppTheme
                                .textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),

                  Row(
                    children: [
                      const Icon(
                        Icons.star,

                        color:
                        Colors.amber,
                        size: 18,
                      ),

                      const SizedBox(
                        width: 4,
                      ),

                      Text(
                        rating
                            .toStringAsFixed(
                          1,
                        ),

                        style:
                        const TextStyle(
                          fontWeight:
                          FontWeight
                              .bold,

                          color: AppTheme
                              .textPrimary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(
                height: 24,
              ),

              Row(
                children: [
                  Expanded(
                    child: _buildInfoTile(
                      title:
                      'Current Tier',

                      value:
                      currentTier,

                      color:
                      _getTierColor(
                        currentTier,
                      ),
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: _buildInfoTile(
                      title:
                      'Next Tier',

                      value:
                      nextTier,

                      color:
                      _getTierColor(
                        nextTier,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(
                height: 24,
              ),

              Container(
                padding:
                const EdgeInsets.all(
                  18,
                ),

                decoration:
                BoxDecoration(
                  color: Colors
                      .grey.shade50,

                  borderRadius:
                  BorderRadius
                      .circular(
                    18,
                  ),
                ),

                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment
                      .start,

                  children: [
                    Row(
                      children: [
                        const Text(
                          'Performance Points',

                          style:
                          TextStyle(
                            fontWeight:
                            FontWeight
                                .w600,

                            color: AppTheme
                                .textPrimary,
                          ),
                        ),

                        const Spacer(),

                        Text(
                          '$currentPoints / $nextTierPoints',

                          style:
                          const TextStyle(
                            color: AppTheme
                                .primaryColor,

                            fontWeight:
                            FontWeight
                                .bold,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                      height: 12,
                    ),

                    ClipRRect(
                      borderRadius:
                      BorderRadius
                          .circular(
                        12,
                      ),

                      child:
                      LinearProgressIndicator(
                        value:
                        animatedProgress,

                        minHeight:
                        12,

                        backgroundColor:
                        Colors.grey
                            .shade200,

                        valueColor:
                        AlwaysStoppedAnimation(
                          _getTierColor(
                            currentTier,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(
                      height: 12,
                    ),

                    Text(
                      remainingPoints == 0
                          ? 'Congratulations! Promotion unlocked.'
                          : '$remainingPoints more points needed to become a $nextTier Partner.',

                      style:
                      const TextStyle(
                        color: AppTheme
                            .textSecondary,

                        height: 1.4,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildInfoTile({
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(
        16,
      ),

      decoration: BoxDecoration(
        color:
        color.withOpacity(
          0.10,
        ),

        borderRadius:
        BorderRadius.circular(
          18,
        ),
      ),

      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          Text(
            title,

            style: const TextStyle(
              color: AppTheme
                  .textSecondary,

              fontSize: 13,
            ),
          ),

          const SizedBox(
            height: 8,
          ),

          Text(
            value,

            style: TextStyle(
              color: color,

              fontSize: 18,

              fontWeight:
              FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}