import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../models/worker_notification.dart';
import '../../providers/notifications_provider.dart';
import '../jobs/job_details_screen.dart';
import 'notification_detail_card.dart';

class NotificationDetailsScreen extends StatefulWidget {
  final int notificationId;

  const NotificationDetailsScreen({
    super.key,
    required this.notificationId,
  });

  @override
  State<NotificationDetailsScreen> createState() =>
      _NotificationDetailsScreenState();
}

class _NotificationDetailsScreenState
    extends State<NotificationDetailsScreen> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback(
          (_) {
        final provider =
        context.read<NotificationsProvider>();

        provider.markAsRead(
          widget.notificationId,
        );
      },
    );
  }

  @override
  Widget build(
      BuildContext context,
      ) {
    return Consumer<NotificationsProvider>(
      builder: (
          context,
          notificationsProvider,
          child,
          ) {
        final WorkerNotification? notification =
        notificationsProvider.getNotificationById(
          widget.notificationId,
        );

        if (notification == null) {
          return Scaffold(
            appBar: AppBar(
              title: const Text(
                'Notification',
              ),
            ),
            body: const Center(
              child: Text(
                'Notification not found.',
              ),
            ),
          );
        }

        return Scaffold(
          backgroundColor:
          AppTheme.scaffoldColor,

          appBar: AppBar(
            title: const Text(
              'Notification',
            ),
            elevation: 0,
          ),

          body: SingleChildScrollView(
            padding:
            const EdgeInsets.all(
              20,
            ),
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment.stretch,
              children: [
                NotificationDetailCard(
                  title:
                  notification.title,

                  message:
                  notification.message,

                  type:
                  notification.type,

                  createdAt:
                  notification.createdAt,

                  orderNumber:
                  notification.orderNumber,

                  isRead:
                  notification.isRead,
                ),

                const SizedBox(
                  height: 20,
                ),

                if (notification.hasAction)
                  _buildActionSection(
                    context,
                    notification,
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildActionSection(
      BuildContext context,
      WorkerNotification notification,
      ) {
    String buttonText =
        'Open';

    IconData buttonIcon =
        Icons.open_in_new;

    VoidCallback? action;

    if (notification.isNewJob ||
        notification.isBonusJob ||
        notification.isCancelledJob) {
      buttonText =
      'View Job';

      buttonIcon =
          Icons.work_outline;

      action = () {
        if (notification.relatedJobId ==
            null) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(
            const SnackBar(
              content: Text(
                'Job information unavailable.',
              ),
            ),
          );

          return;
        }

        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) =>
                JobDetailsScreen(
                  jobId:
                  notification
                      .relatedJobId!,
                ),
          ),
        );
      };
    } else if (notification
        .isVerification) {
      buttonText =
      'Go to Profile';

      buttonIcon =
          Icons.verified_user;

      action = () {
        Navigator.pop(
          context,
        );
      };
    } else if (notification
        .isPayment) {
      buttonText =
      'View Earnings';

      buttonIcon =
          Icons.account_balance_wallet;

      action = () {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(
          const SnackBar(
            content: Text(
              'Navigate to Earnings screen.',
            ),
          ),
        );
      };
    } else {
      buttonText =
      'Close';

      buttonIcon =
          Icons.check;

      action = () {
        Navigator.pop(
          context,
        );
      };
    }

    return Container(
      padding:
      const EdgeInsets.all(
        20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),

            blurRadius: 16,

            offset:
            const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          const Text(
            'Available Action',
            style: TextStyle(
              fontSize: 18,
              fontWeight:
              FontWeight.bold,
              color:
              AppTheme.textPrimary,
            ),
          ),

          const SizedBox(
            height: 16,
          ),

          SizedBox(
            width: double.infinity,

            child: ElevatedButton.icon(
              onPressed: action,

              icon: Icon(
                buttonIcon,
              ),

              label: Text(
                buttonText,
              ),

              style:
              ElevatedButton.styleFrom(
                padding:
                const EdgeInsets.symmetric(
                  vertical: 16,
                ),

                backgroundColor:
                AppTheme
                    .primaryColor,

                foregroundColor:
                Colors.white,

                shape:
                RoundedRectangleBorder(
                  borderRadius:
                  BorderRadius.circular(
                    14,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}