import '../models/worker.dart';
import 'demo_workers.dart';

class DemoAuthService {
  static Worker? _currentWorker;

  /// Returns currently logged in worker
  static Worker? get currentUser =>
      _currentWorker;

  /// Whether worker is logged in
  static bool get isLoggedIn =>
      _currentWorker != null;

  /// Login using email or mobile
  static Future<Worker?> login({
    required String email,
    required String password,
  }) async {
    await Future.delayed(
      const Duration(seconds: 1),
    );

    try {
      final worker =
      DemoWorkers.workers.firstWhere(
            (worker) =>
        (worker.email
            .toLowerCase() ==
            email
                .trim()
                .toLowerCase() ||
            worker.mobile ==
                email.trim()) &&
            worker.password ==
                password.trim(),
      );

      _currentWorker = worker;

      DemoWorkers.setCurrentWorker(
        worker,
      );

      return worker;
    } catch (_) {
      return null;
    }
  }

  /// Register a new worker
  static Future<bool> register({
    required Worker worker,
    required String password,
  }) async {
    await Future.delayed(
      const Duration(seconds: 2),
    );

    final emailExists =
    DemoWorkers.workers.any(
          (existingWorker) =>
      existingWorker.email
          .toLowerCase() ==
          worker.email.toLowerCase(),
    );

    if (emailExists) {
      return false;
    }

    final mobileExists =
    DemoWorkers.workers.any(
          (existingWorker) =>
      existingWorker.mobile ==
          worker.mobile,
    );

    if (mobileExists) {
      return false;
    }

    final newWorker =
    worker.copyWith(
      password: password,
    );

    DemoWorkers.workers.add(
      newWorker,
    );

    return true;
  }

  /// Logout current worker
  static Future<void> logout() async {
    await Future.delayed(
      const Duration(
        milliseconds: 300,
      ),
    );

    _currentWorker = null;

    DemoWorkers.logout();
  }

  /// Restore demo session
  static Future<bool>
  restoreSession() async {
    await Future.delayed(
      const Duration(
        milliseconds: 300,
      ),
    );

    if (_currentWorker != null) {
      return true;
    }

    if (DemoWorkers.currentWorker !=
        null) {
      _currentWorker =
          DemoWorkers.currentWorker;

      return true;
    }

    return false;
  }

  /// Refresh current worker data
  static Future<Worker?>
  refreshWorker() async {
    await Future.delayed(
      const Duration(
        milliseconds: 500,
      ),
    );

    if (_currentWorker == null) {
      return null;
    }

    try {
      final updatedWorker =
      DemoWorkers.workers
          .firstWhere(
            (worker) =>
        worker.id ==
            _currentWorker!.id,
      );

      _currentWorker =
          updatedWorker;

      return updatedWorker;
    } catch (_) {
      return null;
    }
  }

  /// Update worker profile
  static Future<bool>
  updateProfile(
      Worker updatedWorker,
      ) async {
    await Future.delayed(
      const Duration(seconds: 1),
    );

    final index = DemoWorkers.workers
        .indexWhere(
          (worker) =>
      worker.id ==
          updatedWorker.id,
    );

    if (index == -1) {
      return false;
    }

    DemoWorkers.workers[index] =
        updatedWorker;

    if (_currentWorker?.id ==
        updatedWorker.id) {
      _currentWorker =
          updatedWorker;
    }

    return true;
  }

  /// Change password
  static Future<bool>
  changePassword({
    required String
    currentPassword,
    required String newPassword,
  }) async {
    await Future.delayed(
      const Duration(seconds: 1),
    );

    if (_currentWorker == null) {
      return false;
    }

    if (_currentWorker!.password !=
        currentPassword) {
      return false;
    }

    final updatedWorker =
    _currentWorker!.copyWith(
      password: newPassword,
    );

    return updateProfile(
      updatedWorker,
    );
  }
}