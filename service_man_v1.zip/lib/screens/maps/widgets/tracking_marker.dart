import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../core/constants/map_constants.dart';
import '../models/location_record.dart';

/// Premium live-tracking marker.
///
/// Features:
/// • Google Maps–style blue dot
/// • Accuracy circle
/// • Heading indicator
/// • Movement animation
/// • Reusable across apps
class TrackingMarker extends StatefulWidget {
  final LocationRecord location;

  /// Whether to display the GPS accuracy halo.
  final bool showAccuracy;

  /// Whether to display the heading indicator.
  final bool showHeading;

  /// Whether to animate the pulsing effect.
  final bool animate;

  const TrackingMarker({
    super.key,
    required this.location,
    this.showAccuracy = true,
    this.showHeading = true,
    this.animate = true,
  });

  @override
  State<TrackingMarker> createState() =>
      _TrackingMarkerState();
}

class _TrackingMarkerState
    extends State<TrackingMarker>
    with SingleTickerProviderStateMixin {
  late final AnimationController
  _animationController;

  late final Animation<double>
  _pulseAnimation;

  @override
  void initState() {
    super.initState();

    _animationController =
        AnimationController(
          vsync: this,
          duration:
          const Duration(seconds: 2),
        );

    _pulseAnimation =
        Tween<double>(
          begin: 1.0,
          end: 1.25,
        ).animate(
          CurvedAnimation(
            parent:
            _animationController,
            curve: Curves.easeInOut,
          ),
        );

    if (widget.animate) {
      _animationController.repeat(
        reverse: true,
      );
    }
  }

  @override
  void didUpdateWidget(
      covariant TrackingMarker oldWidget,
      ) {
    super.didUpdateWidget(oldWidget);

    if (widget.animate &&
        !_animationController
            .isAnimating) {
      _animationController.repeat(
        reverse: true,
      );
    }

    if (!widget.animate &&
        _animationController
            .isAnimating) {
      _animationController.stop();
    }
  }

  @override
  void dispose() {
    _animationController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (_, __) {
        return Stack(
          alignment: Alignment.center,
          children: [
            // Accuracy Halo
            if (widget.showAccuracy)
              Transform.scale(
                scale: widget.animate
                    ? _pulseAnimation
                    .value
                    : 1,
                child: Container(
                  width:
                  MapConstants
                      .markerOuterRadius *
                      2,
                  height:
                  MapConstants
                      .markerOuterRadius *
                      2,
                  decoration:
                  BoxDecoration(
                    shape:
                    BoxShape.circle,
                    color:
                    MapConstants
                        .markerAccuracyColor,
                  ),
                ),
              ),

            // Heading Arrow
            if (widget.showHeading &&
                widget.location
                    .heading >
                    0)
              Transform.rotate(
                angle:
                widget.location
                    .heading *
                    math.pi /
                    180,
                child: Transform
                    .translate(
                  offset:
                  const Offset(
                    0,
                    -24,
                  ),
                  child: const Icon(
                    Icons
                        .navigation,
                    size: 18,
                    color:
                    Colors.blue,
                  ),
                ),
              ),

            // Marker Border
            Container(
              width:
              MapConstants
                  .markerInnerRadius *
                  2,
              height:
              MapConstants
                  .markerInnerRadius *
                  2,
              decoration:
              BoxDecoration(
                shape:
                BoxShape.circle,
                color:
                MapConstants
                    .markerPrimaryColor,
                border:
                Border.all(
                  color:
                  MapConstants
                      .markerBorderColor,
                  width:
                  MapConstants
                      .markerBorderWidth,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color(
                      0x33000000,
                    ),
                    blurRadius: 8,
                    offset:
                    Offset(
                      0,
                      3,
                    ),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}