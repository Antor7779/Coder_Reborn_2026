import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../providers/auth_provider.dart';
import '../../models/worker.dart';
import '../../widgets/inputs/app_text_field.dart';
import '../../widgets/buttons/gradient_button.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _fullNameController;
  late TextEditingController _mobileController;
  late TextEditingController _emailController;
  late TextEditingController _addressController;
  late TextEditingController _tradeCategoryController;
  late TextEditingController _experienceController;
  late TextEditingController _skillsController;
  late TextEditingController _profileImageController;

  @override
  void initState() {
    super.initState();
    final worker = Provider.of<AuthProvider>(context, listen: false).currentWorker;
    _fullNameController = TextEditingController(text: worker?.fullName ?? '');
    _mobileController = TextEditingController(text: worker?.mobile ?? '');
    _emailController = TextEditingController(text: worker?.email ?? '');
    _addressController = TextEditingController(text: worker?.address ?? '');
    _tradeCategoryController = TextEditingController(text: worker?.tradeCategory ?? '');
    _experienceController = TextEditingController(
        text: worker != null ? worker.experienceYears.toString() : '');
    _skillsController = TextEditingController(
        text: worker != null ? worker.skills.join(', ') : '');
    _profileImageController = TextEditingController(text: worker?.profileImage ?? '');
  }

  @override
  void dispose() {
    _fullNameController.dispose();
    _mobileController.dispose();
    _emailController.dispose();
    _addressController.dispose();
    _tradeCategoryController.dispose();
    _experienceController.dispose();
    _skillsController.dispose();
    _profileImageController.dispose();
    super.dispose();
  }

  Future<void> _saveProfile() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final currentWorker = authProvider.currentWorker;
    if (currentWorker == null) {
      return;
    }
    final updatedWorker = currentWorker.copyWith(
      fullName: _fullNameController.text.trim(),
      mobile: _mobileController.text.trim(),
      email: _emailController.text.trim(),
      address: _addressController.text.trim(),
      tradeCategory: _tradeCategoryController.text.trim(),
      experienceYears:
      int.tryParse(_experienceController.text.trim()) ?? currentWorker.experienceYears,
      skills: _skillsController.text
          .split(',')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList(),
      profileImage: _profileImageController.text.trim(),
    );
    final success = await authProvider.updateProfile(updatedWorker);
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile updated successfully.')),
      );
      if (context.mounted) {
        Navigator.pop(context);
      }
    } else {
      final error = authProvider.errorMessage ?? 'Failed to update profile.';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = Provider.of<AuthProvider>(context).isLoading;

    return Scaffold(
      backgroundColor: AppTheme.scaffoldColor,
      appBar: AppBar(
        title: const Text('Edit Profile'),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                AppTextField(
                  controller: _fullNameController,
                  hintText: 'Full Name',
                  label: 'Full Name',
                  prefixIcon: Icons.person,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter full name.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextField(
                  controller: _mobileController,
                  hintText: 'Mobile Number',
                  label: 'Mobile Number',
                  prefixIcon: Icons.phone,
                  keyboardType: TextInputType.phone,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter mobile number.';
                    }
                    if (!RegExp(r'^\d+$').hasMatch(value.trim())) {
                      return 'Please enter a valid number.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextField(
                  controller: _emailController,
                  hintText: 'Email',
                  label: 'Email',
                  prefixIcon: Icons.email,
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter email.';
                    }
                    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value.trim())) {
                      return 'Enter a valid email address.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextField(
                  controller: _addressController,
                  hintText: 'Address',
                  label: 'Address',
                  prefixIcon: Icons.location_on,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter address.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextField(
                  controller: _tradeCategoryController,
                  hintText: 'Trade Category',
                  label: 'Trade Category',
                  prefixIcon: Icons.build,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter trade category.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextField(
                  controller: _experienceController,
                  hintText: 'Experience (years)',
                  label: 'Experience (years)',
                  prefixIcon: Icons.timeline,
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter experience.';
                    }
                    if (int.tryParse(value.trim()) == null) {
                      return 'Enter a valid number of years.';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextField(
                  controller: _skillsController,
                  hintText: 'Skills (comma separated)',
                  label: 'Skills',
                  prefixIcon: Icons.star,
                  validator: (value) {
                    // skills can be empty
                    return null;
                  },
                ),
                const SizedBox(height: 16),
                AppTextField(
                  controller: _profileImageController,
                  hintText: 'Profile Image URL',
                  label: 'Profile Image URL',
                  prefixIcon: Icons.image,
                  validator: (value) {
                    // profile image can be empty or a valid URL pattern
                    return null;
                  },
                ),
                const SizedBox(height: 24),
                GradientButton(
                  onPressed: isLoading ? null : _saveProfile,
                  text: isLoading ? 'Saving...' : 'Save Profile',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
