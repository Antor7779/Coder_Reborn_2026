
import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../mock/demo_job_requests.dart';
import '../../models/job_request.dart';
import 'widgets/pending_job_card.dart';

class PendingJobsScreen extends StatefulWidget {
const PendingJobsScreen({
super.key,
});

@override
State<PendingJobsScreen> createState() =>
_PendingJobsScreenState();
}

class _PendingJobsScreenState
extends State<PendingJobsScreen> {
List<JobRequest> _jobs = [];

@override
void initState() {
super.initState();

_loadJobs();
}

void _loadJobs() {
_jobs =
DemoJobRequests.pendingRequests;
}

Future<void> _refresh() async {
await Future.delayed(
const Duration(
milliseconds: 500,
),
);

if (!mounted) {
return;
}

setState(() {
_loadJobs();
});
}

void _acceptJob(
JobRequest job,
) {
DemoJobRequests.acceptJob(
job.id,
);

setState(() {
_loadJobs();
});

ScaffoldMessenger.of(
context,
).showSnackBar(
SnackBar(
content: Text(
'${job.serviceName} accepted successfully.',
),
),
);
}

void _rejectJob(
JobRequest job,
) {
DemoJobRequests.rejectJob(
job.id,
);

setState(() {
_loadJobs();
});

ScaffoldMessenger.of(
context,
).showSnackBar(
SnackBar(
content: Text(
'${job.serviceName} rejected.',
),
),
);
}

void _showDetails(
JobRequest job,
) {
showDialog(
context: context,

builder: (_) {
return AlertDialog(
title: Text(
job.serviceName,
),

content: SingleChildScrollView(
child: Column(
crossAxisAlignment:
CrossAxisAlignment
    .start,

mainAxisSize:
MainAxisSize.min,

children: [
Text(
'Order: ${job.orderNumber}',
),

const SizedBox(
height: 12,
),

Text(
'Category: ${job.serviceCategory}',
),

const SizedBox(
height: 12,
),

Text(
'Notes:',
),

const SizedBox(
height: 6,
),

Text(
job.notes,
),
],
),
),

actions: [
TextButton(
onPressed: () {
Navigator.pop(
context,
);
},

child: const Text(
'Close',
),
),
],
);
},
);
}

@override
Widget build(
BuildContext context,
) {
return Scaffold(
backgroundColor:
AppTheme.scaffoldColor,

appBar: AppBar(
title: const Text(
'Pending Jobs',
),
),

body: RefreshIndicator(
onRefresh: _refresh,

child: _jobs.isEmpty
? _buildEmptyState()
    : Column(
children: [
_buildHeader(),

Expanded(
child:
ListView.builder(
physics:
const BouncingScrollPhysics(),

padding:
const EdgeInsets
    .all(
20,
),

itemCount:
_jobs.length,

itemBuilder: (
context,
index,
) {
final job =
_jobs[index];

return PendingJobCard(
job: job,

onAccept:
() {
_acceptJob(
job,
);
},

onReject:
() {
_rejectJob(
job,
);
},

onViewDetails:
() {
_showDetails(
job,
);
},
);
},
),
),
],
),
),
);
}

Widget _buildHeader() {
return Container(
margin:
const EdgeInsets.all(
20,
),

padding:
const EdgeInsets.all(
20,
),

decoration: BoxDecoration(
color: Colors.white,

borderRadius:
BorderRadius.circular(
24,
),

boxShadow: [
BoxShadow(
color: Colors.black
    .withOpacity(
0.05,
),

blurRadius: 16,

offset:
const Offset(
0,
8,
),
),
],
),

child: Row(
children: [
Expanded(
child: Column(
children: [
const Text(
'Pending Requests',
),

const SizedBox(
height: 6,
),

Text(
'${_jobs.length}',

style:
const TextStyle(
fontSize: 28,

fontWeight:
FontWeight
    .bold,
),
),
],
),
),

Expanded(
child: Column(
children: const [
Icon(
Icons.pending_actions,

color:
AppTheme
    .primaryColor,

size: 36,
),

SizedBox(
height: 6,
),

Text(
'Awaiting Action',
),
],
),
),
],
),
);
}

Widget _buildEmptyState() {
return ListView(
physics:
const AlwaysScrollableScrollPhysics(),

children: [
SizedBox(
height:
MediaQuery.of(
context,
).size.height *
0.2,
),

const Icon(
Icons.inbox_outlined,

size: 90,

color: Colors.grey,
),

const SizedBox(
height: 24,
),

const Center(
child: Text(
'No Pending Jobs',

style: TextStyle(
fontSize: 24,

fontWeight:
FontWeight.bold,
),
),
),

const SizedBox(
height: 12,
),

const Padding(
padding:
EdgeInsets.symmetric(
horizontal: 40,
),

child: Text(
'New service requests will appear here.',

textAlign:
TextAlign.center,

style: TextStyle(
color: AppTheme
    .textSecondary,

fontSize: 16,
),
),
),
],
);
}
}

