import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../models/active_job.dart';
import '../../providers/jobs_provider.dart';
import 'widgets/job_actions_section.dart';
import 'widgets/job_bonus_card.dart';
import 'widgets/job_customer_card.dart';
import 'widgets/job_location_card.dart';
import 'widgets/job_notes_card.dart';
import 'widgets/job_service_card.dart';

class JobDetailsScreen extends StatelessWidget {
  final int jobId;

  const JobDetailsScreen({
    super.key,
    required this.jobId,
  });

  @override
  Widget build(BuildContext context) {
    return Consumer<JobsProvider>(
      builder: (
          context,
          jobsProvider,
          child,
          ) {
        final ActiveJob? job =
        jobsProvider.getActiveJob(
          jobId,
        );

        if (job == null) {
          return Scaffold(
            appBar: AppBar(
              title: const Text(
                'Job Details',
              ),
            ),
            body: const Center(
              child: Text(
                'Job not found.',
              ),
            ),
          );
        }

        return Scaffold(
          backgroundColor:
          AppTheme.scaffoldColor,

          appBar: AppBar(
            title: Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .start,
              children: [
                const Text(
                  'Job Details',
                ),
                Text(
                  job.orderNumber,
                  style:
                  const TextStyle(
                    fontSize: 12,
                  ),
                ),
              ],
            ),

            elevation: 0,
          ),

          body:
          SingleChildScrollView(
            padding:
            const EdgeInsets.all(
              16,
            ),

            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .stretch,

              children: [
                _buildStatusCard(
                  job,
                ),

                const SizedBox(
                  height: 16,
                ),

                JobCustomerCard(
                  job: job,
                  onCallCustomer:
                      () {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Calling ${job.customerPhone}',
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(
                  height: 16,
                ),

                JobServiceCard(
                  job: job,
                ),

                const SizedBox(
                  height: 16,
                ),

                JobLocationCard(
                  job: job,
                  onOpenMap: () {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(
                      const SnackBar(
                        content: Text(
                          'Opening Maps...',
                        ),
                      ),
                    );
                  },
                ),

                const SizedBox(
                  height: 16,
                ),

                JobNotesCard(
                  notes:
                  job.notes,
                ),

                const SizedBox(
                  height: 16,
                ),

                JobBonusCard(
                  job: job,
                ),

                const SizedBox(
                  height: 16,
                ),

                JobActionsSection(
                  job: job,

                  onStartJob:
                      () async {
                    if (job
                        .isAccepted) {
                      await jobsProvider
                          .markOnTheWay(
                        job.id,
                      );
                    } else {
                      await jobsProvider
                          .startJob(
                        job.id,
                      );
                    }
                  },

                  onMarkArrived:
                      () async {
                    await jobsProvider
                        .markArrived(
                      job.id,
                    );
                  },

                  onCompleteJob:
                      () async {
                    await jobsProvider
                        .completeJob(
                      job.id,
                    );

                    if (context
                        .mounted) {
                      ScaffoldMessenger
                          .of(
                        context,
                      )
                          .showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Job completed successfully.',
                          ),
                        ),
                      );
                    }
                  },
                ),

                const SizedBox(
                  height: 32,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatusCard(
      ActiveJob job,
      ) {
    Color color =
        Colors.blue;

    IconData icon =
        Icons.assignment;

    if (job.isOnTheWay) {
      color =
          Colors.orange;

      icon =
          Icons.directions_car;
    } else if (job
        .isArrived) {
      color =
          Colors.deepPurple;

      icon =
          Icons.location_on;
    } else if (job
        .isInProgress) {
      color =
          Colors.teal;

      icon =
          Icons.build;
    } else if (job
        .isCompletedStatus) {
      color =
          Colors.green;

      icon =
          Icons.check_circle;
    }

    return Container(
      padding:
      const EdgeInsets.all(
        20,
      ),

      decoration:
      BoxDecoration(
        color:
        Colors.white,

        borderRadius:
        BorderRadius.circular(
          24,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors
                .black
                .withOpacity(
              0.05,
            ),

            blurRadius:
            16,

            offset:
            const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Row(
        children: [
          Container(
            width: 64,

            height: 64,

            decoration:
            BoxDecoration(
              color: color
                  .withOpacity(
                0.1,
              ),

              borderRadius:
              BorderRadius.circular(
                20,
              ),
            ),

            child: Icon(
              icon,

              color: color,

              size: 32,
            ),
          ),

          const SizedBox(
            width: 16,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .start,

              children: [
                const Text(
                  'Current Status',

                  style:
                  TextStyle(
                    color:
                    AppTheme
                        .textSecondary,
                  ),
                ),

                const SizedBox(
                  height: 6,
                ),

                Text(
                  job.status,

                  style:
                  TextStyle(
                    fontSize:
                    22,

                    fontWeight:
                    FontWeight
                        .bold,

                    color:
                    color,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}