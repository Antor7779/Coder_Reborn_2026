import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart'
as permission_handler;

/// Professional permission helper for location tracking.
///
/// Responsibilities:
/// - Check if GPS services are enabled
/// - Request location permissions
/// - Detect permanently denied permissions
/// - Open device settings when needed
class PermissionHelper {
  PermissionHelper._();

  /// Returns true if device location services (GPS) are enabled.
  static Future<bool> isLocationServiceEnabled() async {
    return await Geolocator.isLocationServiceEnabled();
  }

  /// Opens the device location settings screen.
  static Future<bool> openLocationSettings() async {
    return await Geolocator.openLocationSettings();
  }

  /// Opens the application settings screen.
  static Future<bool> openAppSettings() async {
    return await permission_handler
        .openAppSettings();
  }

  /// Returns the current location permission status.
  static Future<LocationPermission>
  checkLocationPermission() async {
    return await Geolocator.checkPermission();
  }

  /// Requests location permission from the user.
  static Future<LocationPermission>
  requestLocationPermission() async {
    return await Geolocator.requestPermission();
  }

  /// Returns true if the application currently has
  /// permission to access location.
  static Future<bool> hasLocationPermission() async {
    final permission =
    await checkLocationPermission();

    return permission ==
        LocationPermission.always ||
        permission ==
            LocationPermission.whileInUse;
  }

  /// Returns true if the user has permanently denied
  /// location permissions.
  static Future<bool>
  isPermissionPermanentlyDenied() async {
    final permission =
    await checkLocationPermission();

    return permission ==
        LocationPermission.deniedForever;
  }

  /// Performs the complete validation process
  /// before starting tracking.
  ///
  /// Returns [PermissionValidationResult]
  /// describing the outcome.
  static Future<PermissionValidationResult>
  validateLocationAccess() async {
    // Step 1: Check GPS
    final gpsEnabled =
    await isLocationServiceEnabled();

    if (!gpsEnabled) {
      return PermissionValidationResult(
        status:
        PermissionValidationStatus
            .gpsDisabled,
        message:
        'Location services are disabled.',
      );
    }

    // Step 2: Check permission
    var permission =
    await checkLocationPermission();

    if (permission ==
        LocationPermission.denied) {
      permission =
      await requestLocationPermission();
    }

    // Step 3: Evaluate result
    if (permission ==
        LocationPermission.denied) {
      return PermissionValidationResult(
        status:
        PermissionValidationStatus
            .permissionDenied,
        message:
        'Location permission was denied.',
      );
    }

    if (permission ==
        LocationPermission.deniedForever) {
      return PermissionValidationResult(
        status:
        PermissionValidationStatus
            .permissionPermanentlyDenied,
        message:
        'Location permission is permanently denied. '
            'Please enable it from app settings.',
      );
    }

    return PermissionValidationResult(
      status:
      PermissionValidationStatus
          .granted,
      message:
      'Location permission granted.',
    );
  }
}

/// Result returned after validating
/// location access requirements.
class PermissionValidationResult {
  final PermissionValidationStatus
  status;

  final String message;

  const PermissionValidationResult({
    required this.status,
    required this.message,
  });

  bool get isGranted =>
      status ==
          PermissionValidationStatus.granted;

  bool get needsAppSettings =>
      status ==
          PermissionValidationStatus
              .permissionPermanentlyDenied;

  bool get needsGps =>
      status ==
          PermissionValidationStatus
              .gpsDisabled;
}

/// Possible outcomes of permission validation.
enum PermissionValidationStatus {
  granted,

  permissionDenied,

  permissionPermanentlyDenied,

  gpsDisabled,
}