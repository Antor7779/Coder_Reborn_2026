import '../models/active_job.dart';

class DemoActiveJobs {
  static List<ActiveJob> activeJobs = [
    ActiveJob(
      id: 1,
      requestId: 101,
      orderNumber: 'SLA-1001',
      workerId: 1,
      workerName: 'Rakib Hasan',
      customerId: 1,
      customerName: 'Antor Shardar',
      customerPhone: '01711111111',
      isForAnotherPerson: true,
      recipientName: 'Rahim Uddin',
      recipientPhone: '01722222222',
      recipientAddress: 'House 15, Road 3, Mirpur 10, Dhaka',
      recipientLatitude: 23.8103,
      recipientLongitude: 90.4125,
      serviceName: 'AC Servicing',
      serviceCategory: 'Home Appliance',
      serviceDescription: 'Full AC servicing and cleaning.',
      servicePrice: 1200,
      acceptedAt: DateTime.now().subtract(
        const Duration(minutes: 25),
      ),
      scheduledDate: DateTime.now(),
      startedAt: null,
      arrivedAt: null,
      completedAt: null,
      status: 'On The Way',
      distanceKm: 4.2,
      estimatedArrival: const Duration(minutes: 20),
      extraTimeTaken: Duration.zero,
      eligibleForBonus: true,
      bonusAmount: 250,
      bonusClaimed: false,
      notes:
      'Customer booked for father. Please call before arrival.',
      isCompleted: false,
      rating: 0.0,
    ),

    ActiveJob(
      id: 2,
      requestId: 102,
      orderNumber: 'SLA-1002',
      workerId: 1,
      workerName: 'Rakib Hasan',
      customerId: 2,
      customerName: 'Nusrat Jahan',
      customerPhone: '01812345678',
      isForAnotherPerson: false,
      recipientName: 'Nusrat Jahan',
      recipientPhone: '01812345678',
      recipientAddress: 'Banani DOHS, Dhaka',
      recipientLatitude: 23.7937,
      recipientLongitude: 90.4066,
      serviceName: 'Deep Cleaning',
      serviceCategory: 'Cleaning',
      serviceDescription: 'Deep cleaning service.',
      servicePrice: 2500,
      acceptedAt: DateTime.now().subtract(
        const Duration(hours: 1),
      ),
      scheduledDate: DateTime.now(),
      startedAt: DateTime.now().subtract(
        const Duration(minutes: 30),
      ),
      arrivedAt: DateTime.now().subtract(
        const Duration(minutes: 35),
      ),
      completedAt: null,
      status: 'In Progress',
      distanceKm: 0,
      estimatedArrival: Duration.zero,
      extraTimeTaken: const Duration(minutes: 15),
      eligibleForBonus: true,
      bonusAmount: 100,
      bonusClaimed: false,
      notes:
      'Customer requested additional balcony cleaning.',
      isCompleted: false,
      rating: 0.0,
    ),

    ActiveJob(
      id: 3,
      requestId: 103,
      orderNumber: 'SLA-1003',
      workerId: 1,
      workerName: 'Rakib Hasan',
      customerId: 3,
      customerName: 'Karim Hasan',
      customerPhone: '01999887766',
      isForAnotherPerson: true,
      recipientName: 'Shamima Begum',
      recipientPhone: '01988776655',
      recipientAddress: 'Gazipur Sadar, Gazipur',
      recipientLatitude: 24.0023,
      recipientLongitude: 90.4264,
      serviceName: 'Plumbing Repair',
      serviceCategory: 'Home Repair',
      serviceDescription: 'Fix leaking pipe.',
      servicePrice: 900,
      acceptedAt: DateTime.now().subtract(
        const Duration(hours: 5),
      ),
      scheduledDate: DateTime.now(),
      startedAt: DateTime.now().subtract(
        const Duration(hours: 4),
      ),
      arrivedAt: DateTime.now().subtract(
        const Duration(hours: 4),
      ),
      completedAt: DateTime.now().subtract(
        const Duration(hours: 2),
      ),
      status: 'Completed',
      distanceKm: 0,
      estimatedArrival: Duration.zero,
      extraTimeTaken: const Duration(minutes: 20),
      eligibleForBonus: true,
      bonusAmount: 200,
      bonusClaimed: true,
      notes:
      'Recipient appreciated the quick response.',
      isCompleted: true,
      rating: 4.8,
    ),
  ];

  static List<ActiveJob> get onTheWayJobs {
    return activeJobs.where(
          (job) => job.status == 'On The Way',
    ).toList();
  }

  static List<ActiveJob> get inProgressJobs {
    return activeJobs.where(
          (job) => job.status == 'In Progress',
    ).toList();
  }

  static List<ActiveJob> get completedJobs {
    return activeJobs.where(
          (job) => job.status == 'Completed',
    ).toList();
  }

  static double get todayEarnings {
    return completedJobs.fold(
      0,
          (total, job) => total + job.servicePrice,
    );
  }

  static double get totalBonusEarned {
    return completedJobs.fold(
      0,
          (total, job) => total + job.bonusAmount,
    );
  }

  static int get totalPointsEarned {
    return completedJobs.fold(
      0,
          (total, job) => total + (job.hasBonus ? 25 : 0),
    );
  }

  static void startJob(int jobId) {
    final index = activeJobs.indexWhere(
          (job) => job.id == jobId,
    );

    if (index == -1) return;

    final job = activeJobs[index];

    activeJobs[index] = job.copyWith(
      status: 'In Progress',
      startedAt: DateTime.now(),
      distanceKm: 0,
    );
  }

  static void completeJob(
      int jobId, {
        Duration extraTimeTaken = Duration.zero,
        double bonusEarned = 0,
        double rating = 5.0,
      }) {
    final index = activeJobs.indexWhere(
          (job) => job.id == jobId,
    );

    if (index == -1) return;

    final job = activeJobs[index];

    activeJobs[index] = job.copyWith(
      status: 'Completed',
      completedAt: DateTime.now(),
      extraTimeTaken: extraTimeTaken,
      bonusAmount: bonusEarned,
      bonusClaimed: bonusEarned > 0,
      isCompleted: true,
      rating: rating,
    );
  }

  static ActiveJob? getById(int id) {
    try {
      return activeJobs.firstWhere(
            (job) => job.id == id,
      );
    } catch (_) {
      return null;
    }
  }
}