import 'dart:async';

import '../models/location_record.dart';
import '../models/tracking_status.dart';
import 'location_service.dart';

/// Handles an entire tracking session.
///
/// Responsibilities:
/// • Start/stop tracking
/// • Maintain current location
/// • Maintain route history
/// • Calculate trip statistics
/// • Expose status changes
class TrackingService {
  TrackingService({
    LocationService? locationService,
  }) : _locationService =
      locationService ?? LocationService();

  final LocationService _locationService;

  StreamSubscription<LocationRecord>?
  _trackingSubscription;

  final List<LocationRecord> _history = [];

  LocationRecord? _currentLocation;

  TrackingStatus _status =
      TrackingStatus.idle;

  DateTime? _sessionStartTime;

  DateTime? _sessionEndTime;

  // ---------------------------------------------------------------------------
  // Getters
  // ---------------------------------------------------------------------------

  TrackingStatus get status => _status;

  LocationRecord? get currentLocation =>
      _currentLocation;

  List<LocationRecord> get history =>
      List.unmodifiable(_history);

  bool get isTracking =>
      _status == TrackingStatus.tracking;

  bool get hasLocation =>
      _currentLocation != null;

  int get pointCount => _history.length;

  DateTime? get sessionStartTime =>
      _sessionStartTime;

  DateTime? get sessionEndTime =>
      _sessionEndTime;

  // ---------------------------------------------------------------------------
  // Tracking Control
  // ---------------------------------------------------------------------------

  Future<void> startTracking({
    Function(LocationRecord)?
    onLocationUpdated,
    Function(TrackingStatus)?
    onStatusChanged,
    Function(Object error)? onError,
  }) async {
    if (isTracking) {
      return;
    }

    try {
      _setStatus(
        TrackingStatus.locating,
        onStatusChanged,
      );

      // Get first location
      final initialLocation =
      await _locationService
          .getCurrentLocation();

      _currentLocation =
          initialLocation;

      _history.clear();

      _history.add(
        initialLocation,
      );

      _sessionStartTime =
          DateTime.now();

      onLocationUpdated?.call(
        initialLocation,
      );

      _setStatus(
        TrackingStatus.tracking,
        onStatusChanged,
      );

      // Start continuous tracking
      _trackingSubscription =
          _locationService
              .startTracking(
            onLocationUpdate: (
                location,
                ) {
              _currentLocation =
                  location;

              _history.add(
                location,
              );

              onLocationUpdated
                  ?.call(
                location,
              );
            },
            onError: (error) {
              _setStatus(
                TrackingStatus.error,
                onStatusChanged,
              );

              onError?.call(
                error,
              );
            },
          );
    } catch (e) {
      _setStatus(
        TrackingStatus.error,
        onStatusChanged,
      );

      onError?.call(e);
    }
  }

  Future<void> stopTracking({
    Function(TrackingStatus)?
    onStatusChanged,
  }) async {
    await _trackingSubscription
        ?.cancel();

    _trackingSubscription =
    null;

    _sessionEndTime =
        DateTime.now();

    _setStatus(
      TrackingStatus.stopped,
      onStatusChanged,
    );
  }

  Future<void> reset({
    Function(TrackingStatus)?
    onStatusChanged,
  }) async {
    await stopTracking(
      onStatusChanged:
      onStatusChanged,
    );

    _history.clear();

    _currentLocation =
    null;

    _sessionStartTime =
    null;

    _sessionEndTime =
    null;

    _setStatus(
      TrackingStatus.idle,
      onStatusChanged,
    );
  }

  // ---------------------------------------------------------------------------
  // Statistics
  // ---------------------------------------------------------------------------

  double get totalDistanceMeters {
    return _locationService
        .calculateTotalDistance(
      _history,
    );
  }

  double get totalDistanceKm {
    return totalDistanceMeters /
        1000;
  }

  double get averageSpeedKmH {
    return _locationService
        .calculateAverageSpeed(
      _history,
    );
  }

  double get maximumSpeedKmH {
    return _locationService
        .calculateMaxSpeed(
      _history,
    );
  }

  Duration get trackingDuration {
    if (_sessionStartTime ==
        null) {
      return Duration.zero;
    }

    final end =
    isTracking
        ? DateTime.now()
        : (_sessionEndTime ??
        DateTime.now());

    return end.difference(
      _sessionStartTime!,
    );
  }

  bool get isMoving {
    if (_currentLocation ==
        null) {
      return false;
    }

    return _locationService
        .isMoving(
      _currentLocation!,
    );
  }

  String get movementType {
    if (_currentLocation ==
        null) {
      return 'Unknown';
    }

    return _locationService
        .movementType(
      _currentLocation!,
    );
  }

  // ---------------------------------------------------------------------------
  // Route Helpers
  // ---------------------------------------------------------------------------

  LocationRecord? get firstPoint {
    if (_history.isEmpty) {
      return null;
    }

    return _history.first;
  }

  LocationRecord? get lastPoint {
    if (_history.isEmpty) {
      return null;
    }

    return _history.last;
  }

  // ---------------------------------------------------------------------------
  // Internal
  // ---------------------------------------------------------------------------

  void _setStatus(
      TrackingStatus status,
      Function(TrackingStatus)?
      callback,
      ) {
    _status = status;

    callback?.call(status);
  }

  // ---------------------------------------------------------------------------
  // Dispose
  // ---------------------------------------------------------------------------

  Future<void> dispose() async {
    await _trackingSubscription
        ?.cancel();

    await _locationService
        .dispose();
  }
}