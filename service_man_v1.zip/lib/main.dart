import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app/app.dart';

import 'providers/auth_provider.dart';
import 'providers/jobs_provider.dart';
import 'providers/notifications_provider.dart';
import 'providers/worker_provider.dart';

// ADD THIS IMPORT
import 'screens/maps/providers/tracking_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<AuthProvider>(
          create: (_) => AuthProvider(),
        ),

        ChangeNotifierProvider<WorkerProvider>(
          create: (_) => WorkerProvider(),
        ),

        ChangeNotifierProvider<JobsProvider>(
          create: (_) => JobsProvider(),
        ),

        ChangeNotifierProvider<NotificationsProvider>(
          create: (_) => NotificationsProvider(),
        ),

        // MAP TRACKING PROVIDER
        ChangeNotifierProvider<TrackingProvider>(
          create: (_) => TrackingProvider(),
        ),
      ],
      child: const ServiceWorkerApp(),
    ),
  );
}