import 'package:flutter/material.dart';

import '../../app/theme.dart';
import '../../mock/demo_notifications.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({
    super.key,
  });

  @override
  State<NotificationsScreen> createState() =>
      _NotificationsScreenState();
}

class _NotificationsScreenState
    extends State<NotificationsScreen> {
  late List<dynamic> _notifications;

  @override
  void initState() {
    super.initState();

    _loadNotifications();
  }

  void _loadNotifications() {
    _notifications =
        DemoNotifications.notifications;
  }

  Future<void> _refresh() async {
    await Future.delayed(
      const Duration(
        milliseconds: 600,
      ),
    );

    if (!mounted) {
      return;
    }

    setState(() {
      _loadNotifications();
    });
  }

  void _markAsRead(
      int index,
      ) {
    setState(() {
      try {
        final notification =
        _notifications[index];

        _notifications[index] =
            notification.copyWith(
              isRead: true,
            );
      } catch (_) {}
    });
  }

  void _markAllAsRead() {
    setState(() {
      for (
      int i = 0;
      i < _notifications.length;
      i++
      ) {
        try {
          _notifications[i] =
              _notifications[i]
                  .copyWith(
                isRead: true,
              );
        } catch (_) {}
      }
    });

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(
      const SnackBar(
        content: Text(
          'All notifications marked as read.',
        ),
      ),
    );
  }

  @override
  Widget build(
      BuildContext context,
      ) {
    return Scaffold(
      backgroundColor:
      AppTheme.scaffoldColor,

      appBar: AppBar(
        title: const Text(
          'Notifications',
        ),

        actions: [
          if (_notifications
              .isNotEmpty)
            TextButton(
              onPressed:
              _markAllAsRead,

              child: const Text(
                'Mark All',
              ),
            ),
        ],
      ),

      body: RefreshIndicator(
        onRefresh: _refresh,

        child:
        _notifications.isEmpty
            ? _buildEmptyState()
            : Column(
          children: [
            _buildHeader(),

            Expanded(
              child:
              ListView.builder(
                physics:
                const BouncingScrollPhysics(),

                padding:
                const EdgeInsets.all(
                  20,
                ),

                itemCount:
                _notifications
                    .length,

                itemBuilder: (
                    context,
                    index,
                    ) {
                  final notification =
                  _notifications[index];

                  return _buildNotificationCard(
                    notification,
                    index,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final unreadCount =
        _notifications.where(
              (notification) {
            try {
              return !notification
                  .isRead;
            } catch (_) {
              return false;
            }
          },
        ).length;

    return Container(
      margin:
      const EdgeInsets.all(
        20,
      ),

      padding:
      const EdgeInsets.all(
        20,
      ),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
        BorderRadius.circular(
          24,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),

            blurRadius: 16,

            offset:
            const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Row(
        children: [
          Expanded(
            child: Column(
              children: [
                const Text(
                  'Total',
                ),

                const SizedBox(
                  height: 6,
                ),

                Text(
                  '${_notifications.length}',

                  style:
                  const TextStyle(
                    fontSize: 28,

                    fontWeight:
                    FontWeight
                        .bold,
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: Column(
              children: [
                const Text(
                  'Unread',
                ),

                const SizedBox(
                  height: 6,
                ),

                Text(
                  '$unreadCount',

                  style:
                  const TextStyle(
                    fontSize: 28,

                    fontWeight:
                    FontWeight
                        .bold,

                    color:
                    AppTheme
                        .primaryColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationCard(
      dynamic notification,
      int index,
      ) {
    final bool isRead =
        notification.isRead ??
            false;

    return TweenAnimationBuilder<
        double
    >(
      duration:
      const Duration(
        milliseconds: 500,
      ),

      tween: Tween(
        begin: 0,
        end: 1,
      ),

      curve:
      Curves.easeOutCubic,

      builder: (
          context,
          value,
          child,
          ) {
        return Transform.translate(
          offset: Offset(
            0,
            20 * (1 - value),
          ),

          child: Opacity(
            opacity: value,

            child: child,
          ),
        );
      },

      child: InkWell(
        borderRadius:
        BorderRadius.circular(
          24,
        ),

        onTap: () {
          _markAsRead(index);
        },

        child: Container(
          margin:
          const EdgeInsets.only(
            bottom: 16,
          ),

          padding:
          const EdgeInsets.all(
            20,
          ),

          decoration:
          BoxDecoration(
            color:
            isRead
                ? Colors.white
                : AppTheme
                .primaryColor
                .withOpacity(
              0.08,
            ),

            borderRadius:
            BorderRadius.circular(
              24,
            ),

            boxShadow: [
              BoxShadow(
                color: Colors
                    .black
                    .withOpacity(
                  0.05,
                ),

                blurRadius:
                16,

                offset:
                const Offset(
                  0,
                  8,
                ),
              ),
            ],
          ),

          child: Row(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,

            children: [
              CircleAvatar(
                radius: 24,

                backgroundColor:
                _getTypeColor(
                  notification
                      .type,
                ),

                child: Icon(
                  _getTypeIcon(
                    notification
                        .type,
                  ),

                  color:
                  Colors
                      .white,
                ),
              ),

              const SizedBox(
                width: 16,
              ),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment
                      .start,

                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            notification
                                .title,

                            style:
                            TextStyle(
                              fontSize:
                              16,

                              fontWeight:
                              isRead
                                  ? FontWeight
                                  .w600
                                  : FontWeight
                                  .bold,
                            ),
                          ),
                        ),

                        if (!isRead)
                          Container(
                            width:
                            10,

                            height:
                            10,

                            decoration:
                            const BoxDecoration(
                              color:
                              Colors
                                  .red,

                              shape:
                              BoxShape
                                  .circle,
                            ),
                          ),
                      ],
                    ),

                    const SizedBox(
                      height: 8,
                    ),

                    Text(
                      notification
                          .message,

                      style:
                      const TextStyle(
                        color:
                        AppTheme
                            .textSecondary,
                      ),
                    ),

                    const SizedBox(
                      height: 12,
                    ),

                    Text(
                      notification
                          .timeAgo,

                      style:
                      const TextStyle(
                        fontSize:
                        12,

                        color:
                        AppTheme
                            .textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return ListView(
      physics:
      const AlwaysScrollableScrollPhysics(),

      children: [
        SizedBox(
          height:
          MediaQuery.of(
            context,
          ).size.height *
              0.2,
        ),

        const Icon(
          Icons.notifications_none,

          size: 90,

          color: Colors.grey,
        ),

        const SizedBox(
          height: 24,
        ),

        const Center(
          child: Text(
            'No Notifications',

            style: TextStyle(
              fontSize: 24,

              fontWeight:
              FontWeight.bold,
            ),
          ),
        ),

        const SizedBox(
          height: 12,
        ),

        const Padding(
          padding:
          EdgeInsets.symmetric(
            horizontal: 40,
          ),

          child: Text(
            'New job alerts and important updates will appear here.',

            textAlign:
            TextAlign.center,

            style: TextStyle(
              color: AppTheme
                  .textSecondary,

              fontSize: 16,
            ),
          ),
        ),
      ],
    );
  }

  IconData _getTypeIcon(
      String type,
      ) {
    switch (
    type.toLowerCase()) {
      case 'job':
        return Icons.work;

      case 'bonus':
        return Icons
            .workspace_premium;

      case 'payment':
        return Icons.payments;

      case 'verification':
        return Icons.verified;

      case 'cancelled':
        return Icons.cancel;

      default:
        return Icons
            .notifications;
    }
  }

  Color _getTypeColor(
      String type,
      ) {
    switch (
    type.toLowerCase()) {
      case 'job':
        return Colors.blue;

      case 'bonus':
        return Colors.amber;

      case 'payment':
        return Colors.green;

      case 'verification':
        return Colors.purple;

      case 'cancelled':
        return Colors.red;

      default:
        return AppTheme
            .primaryColor;
    }
  }
}