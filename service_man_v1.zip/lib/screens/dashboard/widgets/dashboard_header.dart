import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../app/theme.dart';

class DashboardHeader extends StatelessWidget {
  final String workerName;

  final String profileImage;

  final double rating;

  final String tier;

  final int points;

  final VoidCallback? onProfileTap;

  final VoidCallback? onNotificationTap;

  const DashboardHeader({
    super.key,
    required this.workerName,
    required this.profileImage,
    required this.rating,
    required this.tier,
    required this.points,
    this.onProfileTap,
    this.onNotificationTap,
  });

  String _getGreeting() {
    final hour = DateTime.now().hour;

    if (hour < 12) {
      return 'Good Morning';
    }

    if (hour < 17) {
      return 'Good Afternoon';
    }

    return 'Good Evening';
  }

  Color _getTierColor() {
    switch (tier.toLowerCase()) {
      case 'bronze':
        return Colors.brown;

      case 'silver':
        return Colors.grey;

      case 'gold':
        return Colors.amber.shade700;

      case 'platinum':
        return Colors.blueGrey;

      default:
        return AppTheme.primaryColor;
    }
  }

  @override
  Widget build(BuildContext context) {
    final today = DateFormat(
      'EEEE, d MMMM',
    ).format(
      DateTime.now(),
    );

    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 700,
      ),

      tween: Tween(
        begin: 0,
        end: 1,
      ),

      curve: Curves.easeOutCubic,

      builder: (
          context,
          value,
          child,
          ) {
        return Transform.translate(
          offset: Offset(
            0,
            20 * (1 - value),
          ),

          child: Opacity(
            opacity: value,

            child: child,
          ),
        );
      },

      child: Container(
        padding: const EdgeInsets.all(
          24,
        ),

        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,

            end: Alignment.bottomRight,

            colors: [
              AppTheme.primaryColor,
              AppTheme.primaryDarkColor,
            ],
          ),

          borderRadius:
          BorderRadius.circular(
            28,
          ),

          boxShadow: [
            BoxShadow(
              color: AppTheme.primaryColor
                  .withOpacity(
                0.25,
              ),

              blurRadius: 20,

              offset: const Offset(
                0,
                10,
              ),
            ),
          ],
        ),

        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,

          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,

                    children: [
                      Text(
                        '${_getGreeting()} 👋',

                        style: const TextStyle(
                          color: Colors.white70,

                          fontSize: 15,

                          fontWeight:
                          FontWeight.w500,
                        ),
                      ),

                      const SizedBox(
                        height: 6,
                      ),

                      Text(
                        workerName,

                        style:
                        const TextStyle(
                          color: Colors.white,

                          fontSize: 28,

                          fontWeight:
                          FontWeight.w800,
                        ),
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      const Text(
                        'Service Partner',

                        style: TextStyle(
                          color:
                          Colors.white70,

                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ),

                IconButton(
                  onPressed:
                  onNotificationTap,

                  icon: const Icon(
                    Icons.notifications_none,

                    color: Colors.white,
                  ),
                ),

                GestureDetector(
                  onTap: onProfileTap,

                  child: Hero(
                    tag: 'worker_profile',

                    child: CircleAvatar(
                      radius: 28,

                      backgroundColor:
                      Colors.white,

                      backgroundImage:
                      profileImage
                          .isNotEmpty
                          ? NetworkImage(
                        profileImage,
                      )
                          : null,

                      child: profileImage
                          .isEmpty
                          ? const Icon(
                        Icons.person,

                        color: AppTheme
                            .primaryColor,

                        size: 32,
                      )
                          : null,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 20,
            ),

            Container(
              padding:
              const EdgeInsets.symmetric(
                horizontal: 14,
                vertical: 12,
              ),

              decoration: BoxDecoration(
                color: Colors.white
                    .withOpacity(
                  0.15,
                ),

                borderRadius:
                BorderRadius.circular(
                  18,
                ),
              ),

              child: Row(
                children: [
                  const Icon(
                    Icons.calendar_today,

                    color: Colors.white,

                    size: 18,
                  ),

                  const SizedBox(
                    width: 10,
                  ),

                  Expanded(
                    child: Text(
                      today,

                      style:
                      const TextStyle(
                        color:
                        Colors.white,

                        fontWeight:
                        FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 18,
            ),

            Row(
              children: [
                Expanded(
                  child: _buildStatChip(
                    icon: Icons.star,

                    title: 'Rating',

                    value:
                    rating.toStringAsFixed(
                      1,
                    ),
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: _buildTierChip(),
                ),
              ],
            ),

            const SizedBox(
              height: 16,
            ),

            Container(
              padding:
              const EdgeInsets.all(
                16,
              ),

              decoration: BoxDecoration(
                color: Colors.white
                    .withOpacity(
                  0.12,
                ),

                borderRadius:
                BorderRadius.circular(
                  18,
                ),
              ),

              child: Row(
                children: [
                  const Icon(
                    Icons.workspace_premium,

                    color: Colors.white,
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,

                      children: [
                        const Text(
                          'Performance Points',

                          style:
                          TextStyle(
                            color: Colors
                                .white70,

                            fontSize: 13,
                          ),
                        ),

                        const SizedBox(
                          height: 4,
                        ),

                        Text(
                          '$points pts',

                          style:
                          const TextStyle(
                            color:
                            Colors.white,

                            fontSize: 20,

                            fontWeight:
                            FontWeight
                                .bold,
                          ),
                        ),
                      ],
                    ),
                  ),

                  const Icon(
                    Icons.trending_up,

                    color: Colors.white,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatChip({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 12,
      ),

      decoration: BoxDecoration(
        color: Colors.white
            .withOpacity(
          0.15,
        ),

        borderRadius:
        BorderRadius.circular(
          18,
        ),
      ),

      child: Row(
        children: [
          Icon(
            icon,

            color: Colors.amber,
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .start,

              children: [
                Text(
                  title,

                  style:
                  const TextStyle(
                    color:
                    Colors.white70,

                    fontSize: 12,
                  ),
                ),

                Text(
                  value,

                  style:
                  const TextStyle(
                    color:
                    Colors.white,

                    fontWeight:
                    FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTierChip() {
    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 14,
        vertical: 12,
      ),

      decoration: BoxDecoration(
        color: Colors.white
            .withOpacity(
          0.15,
        ),

        borderRadius:
        BorderRadius.circular(
          18,
        ),
      ),

      child: Row(
        children: [
          Icon(
            Icons.emoji_events,

            color: _getTierColor(),
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
              CrossAxisAlignment
                  .start,

              children: [
                const Text(
                  'Current Tier',

                  style: TextStyle(
                    color:
                    Colors.white70,

                    fontSize: 12,
                  ),
                ),

                Text(
                  tier.toUpperCase(),

                  style:
                  const TextStyle(
                    color:
                    Colors.white,

                    fontWeight:
                    FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}