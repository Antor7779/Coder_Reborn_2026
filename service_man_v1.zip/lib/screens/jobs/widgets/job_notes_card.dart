import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class JobNotesCard extends StatelessWidget {
  final String notes;

  const JobNotesCard({
    super.key,
    required this.notes,
  });

  @override
  Widget build(BuildContext context) {
    final bool hasNotes =
        notes.trim().isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(
        20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),
            blurRadius: 15,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration:
                BoxDecoration(
                  color: Colors.amber
                      .withOpacity(
                    0.12,
                  ),
                  borderRadius:
                  BorderRadius
                      .circular(
                    14,
                  ),
                ),
                child: const Icon(
                  Icons.sticky_note_2,
                  color: Colors.amber,
                ),
              ),

              const SizedBox(
                width: 14,
              ),

              const Expanded(
                child: Text(
                  'Customer Notes',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight:
                    FontWeight.bold,
                    color: AppTheme
                        .textPrimary,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 20,
          ),

          if (hasNotes)
            Container(
              width:
              double.infinity,
              padding:
              const EdgeInsets.all(
                16,
              ),
              decoration:
              BoxDecoration(
                color: Colors.amber
                    .withOpacity(
                  0.06,
                ),
                borderRadius:
                BorderRadius.circular(
                  14,
                ),
                border: Border.all(
                  color: Colors.amber
                      .withOpacity(
                    0.30,
                  ),
                ),
              ),
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment
                    .start,
                children: [
                  const Padding(
                    padding:
                    EdgeInsets.only(
                      top: 2,
                    ),
                    child: Icon(
                      Icons.info_outline,
                      color:
                      Colors.amber,
                      size: 22,
                    ),
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: Text(
                      notes,
                      style:
                      const TextStyle(
                        fontSize: 15,
                        height: 1.5,
                        color: AppTheme
                            .textPrimary,
                      ),
                    ),
                  ),
                ],
              ),
            )
          else
            Container(
              width:
              double.infinity,
              padding:
              const EdgeInsets.all(
                16,
              ),
              decoration:
              BoxDecoration(
                color: Colors.grey
                    .withOpacity(
                  0.08,
                ),
                borderRadius:
                BorderRadius.circular(
                  14,
                ),
              ),
              child: Row(
                children: const [
                  Icon(
                    Icons.notes,
                    color: AppTheme
                        .textSecondary,
                  ),

                  SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: Text(
                      'No special instructions provided by the customer.',
                      style:
                      TextStyle(
                        fontSize: 14,
                        color: AppTheme
                            .textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          const SizedBox(
            height: 20,
          ),

          Container(
            padding:
            const EdgeInsets.all(
              14,
            ),
            decoration:
            BoxDecoration(
              color: AppTheme
                  .primaryColor
                  .withOpacity(
                0.08,
              ),
              borderRadius:
              BorderRadius.circular(
                12,
              ),
            ),
            child: Row(
              children: const [
                Icon(
                  Icons.lightbulb_outline,
                  color: AppTheme
                      .primaryColor,
                ),

                SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: Text(
                    'Read customer instructions carefully before starting the service.',
                    style:
                    TextStyle(
                      fontSize: 13,
                      color: AppTheme
                          .textPrimary,
                      fontWeight:
                      FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}