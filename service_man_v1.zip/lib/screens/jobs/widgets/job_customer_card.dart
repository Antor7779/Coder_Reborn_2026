import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../models/active_job.dart';

class JobCustomerCard extends StatelessWidget {
  final ActiveJob job;

  final VoidCallback? onCallCustomer;

  const JobCustomerCard({
    super.key,
    required this.job,
    this.onCallCustomer,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 15,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.person,
                  color: AppTheme.primaryColor,
                ),
              ),
              const SizedBox(width: 14),
              const Expanded(
                child: Text(
                  'Customer Information',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.textPrimary,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          _buildInfoRow(
            icon: Icons.person_outline,
            title: 'Booked By',
            value: job.customerName,
          ),

          const SizedBox(height: 14),

          _buildInfoRow(
            icon: Icons.phone_outlined,
            title: 'Phone Number',
            value: job.customerPhone,
          ),

          const SizedBox(height: 14),

          _buildInfoRow(
            icon: job.isForAnotherPerson
                ? Icons.people_outline
                : Icons.person_pin,
            title: 'Service Receiver',
            value: job.isForAnotherPerson
                ? 'Booked for another person'
                : 'Booked for self',
          ),

          if (job.isForAnotherPerson) ...[
            const SizedBox(height: 20),
            const Divider(),
            const SizedBox(height: 16),

            const Text(
              'Recipient Information',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
            ),

            const SizedBox(height: 16),

            _buildInfoRow(
              icon: Icons.person_2_outlined,
              title: 'Recipient Name',
              value: job.recipientName,
            ),

            const SizedBox(height: 14),

            _buildInfoRow(
              icon: Icons.phone_outlined,
              title: 'Recipient Phone',
              value: job.recipientPhone,
            ),
          ],

          const SizedBox(height: 24),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: onCallCustomer,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(
                  vertical: 14,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              icon: const Icon(Icons.call),
              label: const Text(
                'Call Customer',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          color: AppTheme.textSecondary,
          size: 22,
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  fontSize: 13,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}