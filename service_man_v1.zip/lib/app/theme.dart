import 'package:flutter/material.dart';

class AppTheme {
  // Brand Colors

  static const Color primaryColor =
  Color(0xFF2563EB);

  static const Color primaryDarkColor =
  Color(0xFF1D4ED8);

  static const Color secondaryColor =
  Color(0xFF06B6D4);

  static const Color successColor =
  Color(0xFF16A34A);

  static const Color warningColor =
  Color(0xFFF59E0B);

  static const Color errorColor =
  Color(0xFFDC2626);

  // Text Colors

  static const Color textPrimary =
  Color(0xFF111827);

  static const Color textSecondary =
  Color(0xFF6B7280);

  // Background Colors

  static const Color scaffoldColor =
  Color(0xFFF8FAFC);

  static const Color cardColor =
      Colors.white;

  static const Color borderColor =
  Color(0xFFE5E7EB);

  // Border Radius

  static const double radiusSM = 12;

  static const double radiusMD = 18;

  static const double radiusLG = 24;

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,

      brightness: Brightness.light,

      scaffoldBackgroundColor:
      scaffoldColor,

      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryColor,

        primary: primaryColor,

        secondary: secondaryColor,

        error: errorColor,
      ),

      appBarTheme: const AppBarTheme(
        elevation: 0,

        centerTitle: true,

        backgroundColor:
        scaffoldColor,

        foregroundColor:
        textPrimary,

        titleTextStyle: TextStyle(
          color: textPrimary,

          fontSize: 20,

          fontWeight:
          FontWeight.w700,
        ),
      ),

      cardTheme: CardThemeData(
        color: cardColor,

        elevation: 0,

        shape: RoundedRectangleBorder(
          borderRadius:
          BorderRadius.circular(
            radiusLG,
          ),
        ),
      ),
      inputDecorationTheme:
      InputDecorationTheme(
        filled: true,

        fillColor: Colors.white,

        contentPadding:
        const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 18,
        ),

        border: OutlineInputBorder(
          borderRadius:
          BorderRadius.circular(
            radiusLG,
          ),

          borderSide:
          const BorderSide(
            color: borderColor,
          ),
        ),

        enabledBorder:
        OutlineInputBorder(
          borderRadius:
          BorderRadius.circular(
            radiusLG,
          ),

          borderSide:
          const BorderSide(
            color: borderColor,
          ),
        ),

        focusedBorder:
        OutlineInputBorder(
          borderRadius:
          BorderRadius.circular(
            radiusLG,
          ),

          borderSide:
          const BorderSide(
            color: primaryColor,
            width: 2,
          ),
        ),
      ),

      elevatedButtonTheme:
      ElevatedButtonThemeData(
        style:
        ElevatedButton.styleFrom(
          elevation: 0,

          minimumSize:
          const Size(
            double.infinity,
            56,
          ),

          shape:
          RoundedRectangleBorder(
            borderRadius:
            BorderRadius.circular(
              radiusLG,
            ),
          ),
        ),
      ),

      dividerTheme:
      const DividerThemeData(
        color: borderColor,
      ),

      snackBarTheme:
      SnackBarThemeData(
        behavior:
        SnackBarBehavior.floating,

        shape:
        RoundedRectangleBorder(
          borderRadius:
          BorderRadius.circular(
            radiusMD,
          ),
        ),
      ),

      fontFamily: 'Roboto',
    );
  }
}