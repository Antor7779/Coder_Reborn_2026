
import 'package:flutter/material.dart';

import '../../app/theme.dart';

class EarningsScreen extends StatefulWidget {
const EarningsScreen({
super.key,
});

@override
State<EarningsScreen> createState() =>
_EarningsScreenState();
}

class _EarningsScreenState
extends State<EarningsScreen> {
final double availableBalance =
18500;

final double todayEarnings =
3200;

final double bonusEarned =
850;

final double withdrawn =
12000;

final double monthlyGoal =
25000;

final double monthlyEarnings =
18500;

final List<Map<String, dynamic>>
earningsHistory = [
{
'title':
'AC Servicing',
'amount': 1200.0,
'date':
'Today',
'bonus': 100.0,
},
{
'title':
'Deep Cleaning',
'amount': 1800.0,
'date':
'Yesterday',
'bonus': 150.0,
},
{
'title':
'Electrician',
'amount': 950.0,
'date':
'Yesterday',
'bonus': 0.0,
},
];

@override
Widget build(
BuildContext context,
) {
final progress =
monthlyEarnings /
monthlyGoal;

return Scaffold(
backgroundColor:
AppTheme.scaffoldColor,

appBar: AppBar(
title: const Text(
'Earnings',
),
),

body: SingleChildScrollView(
padding:
const EdgeInsets.all(
20,
),

child: Column(
children: [
TweenAnimationBuilder<
double>(
duration:
const Duration(
milliseconds:
700,
),

tween: Tween(
begin: 0,
end: 1,
),

builder: (
context,
value,
child,
) {
return Transform
    .scale(
scale: value,

child: child,
);
},

child: Container(
padding:
const EdgeInsets
    .all(
24,
),

decoration:
BoxDecoration(
gradient:
const LinearGradient(
colors: [
AppTheme
    .primaryColor,
AppTheme
    .primaryDarkColor,
],
),

borderRadius:
BorderRadius
    .circular(
28,
),
),

child: Column(
children: [
const Text(
'Available Balance',

style:
TextStyle(
color: Colors
    .white70,
),
),

const SizedBox(
height:
12,
),

Text(
'৳${availableBalance.toStringAsFixed(0)}',

style:
const TextStyle(
color:
Colors
    .white,

fontSize:
36,

fontWeight:
FontWeight
    .bold,
),
),

const SizedBox(
height:
24,
),

ElevatedButton
    .icon(
onPressed:
() {
ScaffoldMessenger.of(
context)
    .showSnackBar(
const SnackBar(
content:
Text(
'Withdraw feature coming soon.',
),
),
);
},

icon:
const Icon(
Icons
    .account_balance_wallet,
),

label:
const Text(
'Withdraw',
),
),
],
),
),
),

const SizedBox(
height: 24,
),

Row(
children: [
Expanded(
child:
_buildStatCard(
title:
'Today',

value:
'৳${todayEarnings.toStringAsFixed(0)}',

icon: Icons
    .today,
),
),

const SizedBox(
width: 16,
),

Expanded(
child:
_buildStatCard(
title:
'Bonus',

value:
'৳${bonusEarned.toStringAsFixed(0)}',

icon: Icons
    .workspace_premium,
),
),
],
),

const SizedBox(
height: 16,
),

_buildStatCard(
title:
'Total Withdrawn',

value:
'৳${withdrawn.toStringAsFixed(0)}',

icon: Icons
    .payments,
),

const SizedBox(
height: 24,
),

Container(
padding:
const EdgeInsets
    .all(
20,
),

decoration:
BoxDecoration(
color:
Colors.white,

borderRadius:
BorderRadius
    .circular(
24,
),
),

child: Column(
crossAxisAlignment:
CrossAxisAlignment
    .start,

children: [
const Text(
'Monthly Goal',

style:
TextStyle(
fontSize:
18,

fontWeight:
FontWeight
    .bold,
),
),

const SizedBox(
height:
16,
),

LinearProgressIndicator(
value:
progress,

minHeight:
12,

borderRadius:
BorderRadius.circular(
12,
),
),

const SizedBox(
height:
12,
),

Text(
'৳${monthlyEarnings.toStringAsFixed(0)} of ৳${monthlyGoal.toStringAsFixed(0)}',
),
],
),
),

const SizedBox(
height: 24,
),

Container(
padding:
const EdgeInsets
    .all(
20,
),

decoration:
BoxDecoration(
color:
Colors.white,

borderRadius:
BorderRadius
    .circular(
24,
),
),

child: Column(
crossAxisAlignment:
CrossAxisAlignment
    .start,

children: [
const Text(
'Earnings History',

style:
TextStyle(
fontSize:
18,

fontWeight:
FontWeight
    .bold,
),
),

const SizedBox(
height:
16,
),

...earningsHistory
    .map(
(
earning,
) {
return ListTile(
contentPadding:
EdgeInsets
    .zero,

leading:
const CircleAvatar(
child:
Icon(
Icons
    .work,
),
),

title:
Text(
earning[
'title'],
),

subtitle:
Text(
earning[
'date'],
),

trailing:
Column(
mainAxisAlignment:
MainAxisAlignment
    .center,

crossAxisAlignment:
CrossAxisAlignment
    .end,

children: [
Text(
'৳${earning['amount']}',
),

if (earning[
'bonus'] >
0)
Text(
'+৳${earning['bonus']} Bonus',

style:
const TextStyle(
color:
Colors.green,

fontSize:
12,
),
),
],
),
);
},
),
],
),
),
],
),
),
);
}

Widget _buildStatCard({
required String title,
required String value,
required IconData icon,
}) {
return Container(
padding:
const EdgeInsets.all(
20,
),

decoration: BoxDecoration(
color: Colors.white,

borderRadius:
BorderRadius.circular(
24,
),
),

child: Column(
children: [
Icon(icon),

const SizedBox(
height: 12,
),

Text(
value,

style:
const TextStyle(
fontSize: 20,

fontWeight:
FontWeight.bold,
),
),

const SizedBox(
height: 6,
),

Text(title),
],
),
);
}
}

