import 'package:flutter/material.dart';

import '../../app/theme.dart';

class GradientButton extends StatelessWidget {
  final String text;

  final VoidCallback? onPressed;

  final bool isLoading;

  final IconData? icon;

  final double height;

  final double borderRadius;

  final List<Color>? gradientColors;

  final EdgeInsetsGeometry? margin;

  final double? width;

  final TextStyle? textStyle;

  const GradientButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.isLoading = false,
    this.icon,
    this.height = 56,
    this.borderRadius = AppTheme.radiusLG,
    this.gradientColors,
    this.margin,
    this.width,
    this.textStyle,
  });

  @override
  Widget build(BuildContext context) {
    final bool isDisabled =
        onPressed == null || isLoading;

    return Container(
      width: width ?? double.infinity,

      height: height,

      margin: margin,

      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(
          borderRadius,
        ),

        gradient: LinearGradient(
          begin: Alignment.topLeft,

          end: Alignment.bottomRight,

          colors: isDisabled
              ? [
            Colors.grey.shade400,
            Colors.grey.shade500,
          ]
              : gradientColors ??
              [
                AppTheme.primaryColor,
                AppTheme.primaryDarkColor,
              ],
        ),

        boxShadow: isDisabled
            ? []
            : [
          BoxShadow(
            color: AppTheme.primaryColor
                .withOpacity(
              0.25,
            ),

            blurRadius: 16,

            offset: const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Material(
        color: Colors.transparent,

        child: InkWell(
          onTap: isDisabled
              ? null
              : onPressed,

          borderRadius:
          BorderRadius.circular(
            borderRadius,
          ),

          child: Center(
            child: AnimatedSwitcher(
              duration: const Duration(
                milliseconds: 250,
              ),

              child: isLoading
                  ? const SizedBox(
                key: ValueKey(
                  'loading',
                ),

                width: 24,

                height: 24,

                child:
                CircularProgressIndicator(
                  color: Colors.white,

                  strokeWidth: 2.5,
                ),
              )
                  : Row(
                key: const ValueKey(
                  'content',
                ),

                mainAxisSize:
                MainAxisSize.min,

                children: [
                  if (icon != null) ...[
                    Icon(
                      icon,

                      color: Colors.white,

                      size: 20,
                    ),

                    const SizedBox(
                      width: 10,
                    ),
                  ],

                  Text(
                    text,

                    style: textStyle ??
                        const TextStyle(
                          color: Colors.white,

                          fontSize: 16,

                          fontWeight:
                          FontWeight.w700,

                          letterSpacing: 0.3,
                        ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}