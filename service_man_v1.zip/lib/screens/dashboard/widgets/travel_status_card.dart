import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class TravelStatusCard extends StatelessWidget {
  final String customerName;

  final String serviceName;

  final double distanceKm;

  final int etaMinutes;

  final int extraTimeMinutes;

  final bool isDelayed;

  final double progress;

  const TravelStatusCard({
    super.key,
    required this.customerName,
    required this.serviceName,
    required this.distanceKm,
    required this.etaMinutes,
    required this.extraTimeMinutes,
    required this.isDelayed,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius: BorderRadius.circular(
          28,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(
              0.05,
            ),

            blurRadius: 18,

            offset: const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          Row(
            children: [
              Container(
                width: 60,

                height: 60,

                decoration: BoxDecoration(
                  color: AppTheme.primaryColor
                      .withOpacity(
                    0.12,
                  ),

                  borderRadius:
                  BorderRadius.circular(
                    18,
                  ),
                ),

                child: const Icon(
                  Icons.navigation,

                  color:
                  AppTheme.primaryColor,

                  size: 30,
                ),
              ),

              const SizedBox(
                width: 16,
              ),

              const Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment.start,

                  children: [
                    Text(
                      'Travel Status',

                      style: TextStyle(
                        fontSize: 20,

                        fontWeight:
                        FontWeight.bold,

                        color:
                        AppTheme.textPrimary,
                      ),
                    ),

                    SizedBox(
                      height: 4,
                    ),

                    Text(
                      'Current destination progress',

                      style: TextStyle(
                        color: AppTheme
                            .textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 24,
          ),

          Container(
            padding:
            const EdgeInsets.all(
              18,
            ),

            decoration:
            BoxDecoration(
              color: Colors
                  .grey.shade50,

              borderRadius:
              BorderRadius.circular(
                18,
              ),
            ),

            child: Column(
              children: [
                _buildRow(
                  Icons.person_outline,
                  'Customer',
                  customerName,
                ),

                const Divider(),

                _buildRow(
                  Icons.build_circle_outlined,
                  'Service',
                  serviceName,
                ),

                const Divider(),

                _buildRow(
                  Icons.location_on_outlined,
                  'Distance Left',
                  '${distanceKm.toStringAsFixed(1)} km',
                ),

                const Divider(),

                _buildRow(
                  Icons.timer_outlined,
                  'ETA',
                  '$etaMinutes min',
                ),
              ],
            ),
          ),

          const SizedBox(
            height: 20,
          ),

          Row(
            children: [
              Expanded(
                child: _metricCard(
                  icon:
                  Icons.schedule,
                  title:
                  'Time Left',
                  value:
                  '$etaMinutes min',
                  color:
                  Colors.blue,
                ),
              ),

              const SizedBox(
                width: 12,
              ),

              Expanded(
                child: _metricCard(
                  icon:
                  Icons.warning_amber,
                  title:
                  'Extra Time',
                  value:
                  '$extraTimeMinutes min',
                  color:
                  isDelayed
                      ? Colors.red
                      : Colors.green,
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 22,
          ),

          Row(
            children: [
              const Expanded(
                child: Text(
                  'Arrival Progress',

                  style: TextStyle(
                    fontWeight:
                    FontWeight.w600,

                    color: AppTheme
                        .textPrimary,
                  ),
                ),
              ),

              Text(
                '${(progress * 100).toInt()}%',

                style: const TextStyle(
                  color:
                  AppTheme.primaryColor,

                  fontWeight:
                  FontWeight.bold,
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 10,
          ),

          TweenAnimationBuilder<double>(
            duration: const Duration(
              milliseconds: 800,
            ),

            tween: Tween(
              begin: 0,
              end: progress,
            ),

            builder: (
                context,
                value,
                child,
                ) {
              return ClipRRect(
                borderRadius:
                BorderRadius.circular(
                  12,
                ),

                child:
                LinearProgressIndicator(
                  value: value,

                  minHeight: 12,

                  backgroundColor:
                  Colors.grey.shade200,

                  valueColor:
                  const AlwaysStoppedAnimation(
                    AppTheme.primaryColor,
                  ),
                ),
              );
            },
          ),

          const SizedBox(
            height: 18,
          ),

          Container(
            padding:
            const EdgeInsets.all(
              16,
            ),

            decoration:
            BoxDecoration(
              color: isDelayed
                  ? Colors.red
                  .withOpacity(
                0.08,
              )
                  : Colors.green
                  .withOpacity(
                0.08,
              ),

              borderRadius:
              BorderRadius.circular(
                16,
              ),
            ),

            child: Row(
              children: [
                Icon(
                  isDelayed
                      ? Icons.warning
                      : Icons.check_circle,

                  color: isDelayed
                      ? Colors.red
                      : Colors.green,
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: Text(
                    isDelayed
                        ? 'Worker is running late. Extra travel time has been recorded.'
                        : 'Worker is on schedule and expected to arrive on time.',

                    style: TextStyle(
                      color: isDelayed
                          ? Colors.red
                          : Colors.green,

                      fontWeight:
                      FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRow(
      IconData icon,
      String title,
      String value,
      ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color:
          AppTheme.primaryColor,
        ),

        const SizedBox(
          width: 10,
        ),

        Text(
          title,

          style: const TextStyle(
            color:
            AppTheme.textSecondary,
          ),
        ),

        const Spacer(),

        Text(
          value,

          style: const TextStyle(
            fontWeight:
            FontWeight.bold,

            color:
            AppTheme.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _metricCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Container(
      padding:
      const EdgeInsets.all(
        16,
      ),

      decoration: BoxDecoration(
        color: color.withOpacity(
          0.08,
        ),

        borderRadius:
        BorderRadius.circular(
          16,
        ),
      ),

      child: Column(
        children: [
          Icon(
            icon,
            color: color,
          ),

          const SizedBox(
            height: 10,
          ),

          Text(
            value,

            style: TextStyle(
              color: color,

              fontWeight:
              FontWeight.bold,

              fontSize: 20,
            ),
          ),

          const SizedBox(
            height: 4,
          ),

          Text(
            title,

            style: const TextStyle(
              color:
              AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}