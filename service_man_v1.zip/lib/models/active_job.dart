class ActiveJob {
  /// Unique active job ID
  final int id;

  /// Original request ID
  final int requestId;

  /// Order number
  final String orderNumber;
  /// Customer rating after completion
  final double rating;
  /// Worker information
  final int workerId;

  final String workerName;

  /// Customer who booked the service
  final int customerId;

  final String customerName;

  final String customerPhone;

  /// Recipient details
  final bool isForAnotherPerson;

  final String recipientName;

  final String recipientPhone;

  final String recipientAddress;

  final double recipientLatitude;

  final double recipientLongitude;

  /// Service information
  final String serviceName;

  final String serviceCategory;

  final String serviceDescription;

  final double servicePrice;

  /// Important timestamps
  final DateTime acceptedAt;

  final DateTime scheduledDate;

  final DateTime? startedAt;

  final DateTime? arrivedAt;

  final DateTime? completedAt;

  /// Worker progress
  ///
  /// Accepted
  /// On The Way
  /// Arrived
  /// In Progress
  /// Completed
  final String status;

  /// Navigation information
  final double distanceKm;

  final Duration estimatedArrival;

  final Duration extraTimeTaken;

  /// Bonus tracking
  final bool eligibleForBonus;

  final double bonusAmount;

  final bool bonusClaimed;

  /// Customer notes
  final String notes;

  /// Completion state
  final bool isCompleted;

  const ActiveJob({
    required this.id,
    required this.requestId,
    required this.orderNumber,
    required this.workerId,
    required this.workerName,
    required this.customerId,
    required this.customerName,
    required this.customerPhone,
    required this.isForAnotherPerson,
    required this.recipientName,
    required this.recipientPhone,
    required this.recipientAddress,
    required this.recipientLatitude,
    required this.recipientLongitude,
    required this.serviceName,
    required this.serviceCategory,
    required this.serviceDescription,
    required this.servicePrice,
    required this.acceptedAt,
    required this.scheduledDate,
    required this.startedAt,
    required this.arrivedAt,
    required this.completedAt,
    required this.status,
    required this.distanceKm,
    required this.estimatedArrival,
    required this.extraTimeTaken,
    required this.eligibleForBonus,
    required this.bonusAmount,
    required this.bonusClaimed,
    required this.notes,
    required this.isCompleted,
    required this.rating,
  });

  ActiveJob copyWith({
    int? id,
    int? requestId,
    String? orderNumber,
    int? workerId,
    String? workerName,
    int? customerId,
    String? customerName,
    String? customerPhone,
    bool? isForAnotherPerson,
    String? recipientName,
    String? recipientPhone,
    String? recipientAddress,
    double? recipientLatitude,
    double? recipientLongitude,
    String? serviceName,
    String? serviceCategory,
    String? serviceDescription,
    double? servicePrice,
    DateTime? acceptedAt,
    DateTime? scheduledDate,
    DateTime? startedAt,
    DateTime? arrivedAt,
    DateTime? completedAt,
    String? status,
    double? distanceKm,
    Duration? estimatedArrival,
    Duration? extraTimeTaken,
    bool? eligibleForBonus,
    double? bonusAmount,
    bool? bonusClaimed,
    String? notes,
    bool? isCompleted,
    double? rating,
  }) {
    return ActiveJob(
      id: id ?? this.id,
      requestId: requestId ?? this.requestId,
      orderNumber: orderNumber ?? this.orderNumber,
      workerId: workerId ?? this.workerId,
      workerName: workerName ?? this.workerName,
      customerId: customerId ?? this.customerId,
      customerName: customerName ?? this.customerName,
      customerPhone: customerPhone ?? this.customerPhone,
      isForAnotherPerson:
      isForAnotherPerson ??
          this.isForAnotherPerson,
      recipientName:
      recipientName ?? this.recipientName,
      recipientPhone:
      recipientPhone ?? this.recipientPhone,
      recipientAddress:
      recipientAddress ??
          this.recipientAddress,
      recipientLatitude:
      recipientLatitude ??
          this.recipientLatitude,
      recipientLongitude:
      recipientLongitude ??
          this.recipientLongitude,
      serviceName:
      serviceName ?? this.serviceName,
      serviceCategory:
      serviceCategory ??
          this.serviceCategory,
      serviceDescription:
      serviceDescription ??
          this.serviceDescription,
      servicePrice:
      servicePrice ?? this.servicePrice,
      acceptedAt:
      acceptedAt ?? this.acceptedAt,
      scheduledDate:
      scheduledDate ?? this.scheduledDate,
      startedAt:
      startedAt ?? this.startedAt,
      arrivedAt:
      arrivedAt ?? this.arrivedAt,
      completedAt:
      completedAt ?? this.completedAt,
      status: status ?? this.status,
      distanceKm:
      distanceKm ?? this.distanceKm,
      estimatedArrival:
      estimatedArrival ??
          this.estimatedArrival,
      extraTimeTaken:
      extraTimeTaken ??
          this.extraTimeTaken,
      eligibleForBonus:
      eligibleForBonus ??
          this.eligibleForBonus,
      bonusAmount:
      bonusAmount ?? this.bonusAmount,
      bonusClaimed:
      bonusClaimed ?? this.bonusClaimed,
      notes: notes ?? this.notes,
      isCompleted:
      isCompleted ?? this.isCompleted,
      rating: rating ?? this.rating,
    );
  }

  /// Status helpers

  bool get isAccepted =>
      status.toLowerCase() ==
          'accepted';

  bool get isOnTheWay =>
      status.toLowerCase() ==
          'on the way';

  bool get isArrived =>
      status.toLowerCase() ==
          'arrived';

  bool get isInProgress =>
      status.toLowerCase() ==
          'in progress';

  bool get isCompletedStatus =>
      status.toLowerCase() ==
          'completed';

  /// Action helpers

  bool get canStartJob =>
      isAccepted ||
          isOnTheWay ||
          isArrived;

  bool get canMarkArrived =>
      isOnTheWay;

  bool get canCompleteJob =>
      isInProgress;

  bool get canOpenMap =>
      !isCompletedStatus;

  bool get canCallCustomer =>
      !isCompletedStatus;

  /// Earnings

  bool get hasBonus =>
      eligibleForBonus &&
          bonusAmount > 0;

  double get totalEarnings =>
      servicePrice + bonusAmount;

  /// Timing

  Duration? get jobDuration {
    if (startedAt == null ||
        completedAt == null) {
      return null;
    }

    return completedAt!.difference(
      startedAt!,
    );
  }
}