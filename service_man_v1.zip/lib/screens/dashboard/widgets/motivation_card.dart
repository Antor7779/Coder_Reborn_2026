import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class MotivationCard extends StatelessWidget {
  final String motivationalQuote;

  final String achievementMessage;

  final int currentRank;

  final int totalWorkers;

  final int streakDays;

  final String bonusMessage;

  const MotivationCard({
    super.key,
    required this.motivationalQuote,
    required this.achievementMessage,
    required this.currentRank,
    required this.totalWorkers,
    required this.streakDays,
    required this.bonusMessage,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: const Duration(
        milliseconds: 800,
      ),
      tween: Tween(
        begin: 0,
        end: 1,
      ),
      curve: Curves.easeOutCubic,
      builder: (
          context,
          value,
          child,
          ) {
        return Transform.translate(
          offset: Offset(
            0,
            (1 - value) * 20,
          ),
          child: Opacity(
            opacity: value,
            child: child,
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(
          24,
        ),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppTheme.primaryColor,
              AppTheme.primaryDarkColor,
            ],
          ),
          borderRadius:
          BorderRadius.circular(
            28,
          ),
          boxShadow: [
            BoxShadow(
              color: AppTheme.primaryColor
                  .withOpacity(
                0.25,
              ),
              blurRadius: 20,
              offset: const Offset(
                0,
                10,
              ),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
          CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 58,
                  height: 58,
                  decoration:
                  BoxDecoration(
                    color: Colors.white
                        .withOpacity(
                      0.15,
                    ),
                    borderRadius:
                    BorderRadius
                        .circular(
                      18,
                    ),
                  ),
                  child: const Icon(
                    Icons.emoji_events,
                    color: Colors.white,
                    size: 32,
                  ),
                ),
                const SizedBox(
                  width: 16,
                ),
                const Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,
                    children: [
                      Text(
                        'Keep Going!',

                        style: TextStyle(
                          color:
                          Colors.white,

                          fontSize: 22,

                          fontWeight:
                          FontWeight
                              .bold,
                        ),
                      ),
                      SizedBox(
                        height: 4,
                      ),
                      Text(
                        'Your dedication drives success.',

                        style: TextStyle(
                          color:
                          Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 24,
            ),

            Container(
              padding:
              const EdgeInsets.all(
                18,
              ),
              decoration:
              BoxDecoration(
                color: Colors.white
                    .withOpacity(
                  0.12,
                ),
                borderRadius:
                BorderRadius
                    .circular(
                  18,
                ),
              ),
              child: Row(
                crossAxisAlignment:
                CrossAxisAlignment
                    .start,
                children: [
                  const Icon(
                    Icons.format_quote,
                    color:
                    Colors.white,
                  ),
                  const SizedBox(
                    width: 12,
                  ),
                  Expanded(
                    child: Text(
                      motivationalQuote,
                      style:
                      const TextStyle(
                        color:
                        Colors.white,
                        fontSize: 15,
                        height: 1.5,
                        fontStyle:
                        FontStyle
                            .italic,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(
              height: 24,
            ),

            Text(
              achievementMessage,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight:
                FontWeight.w600,
                height: 1.5,
              ),
            ),

            const SizedBox(
              height: 24,
            ),

            Row(
              children: [
                Expanded(
                  child: _buildMetric(
                    icon:
                    Icons.leaderboard,
                    title:
                    'Current Rank',
                    value:
                    '#$currentRank',
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: _buildMetric(
                    icon:
                    Icons.groups,
                    title:
                    'Workers',
                    value:
                    '$totalWorkers',
                  ),
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: _buildMetric(
                    icon:
                    Icons.local_fire_department,
                    title:
                    'Streak',
                    value:
                    '$streakDays Days',
                  ),
                ),
              ],
            ),

            const SizedBox(
              height: 24,
            ),

            Container(
              padding:
              const EdgeInsets.all(
                16,
              ),
              decoration:
              BoxDecoration(
                color: Colors.white
                    .withOpacity(
                  0.12,
                ),
                borderRadius:
                BorderRadius
                    .circular(
                  16,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.card_giftcard,
                    color:
                    Colors.white,
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: Text(
                      bonusMessage,
                      style:
                      const TextStyle(
                        color:
                        Colors.white,
                        height: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMetric({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding:
      const EdgeInsets.all(
        14,
      ),
      decoration: BoxDecoration(
        color: Colors.white
            .withOpacity(
          0.12,
        ),
        borderRadius:
        BorderRadius.circular(
          16,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: Colors.white,
          ),

          const SizedBox(
            height: 8,
          ),

          Text(
            value,
            textAlign:
            TextAlign.center,
            style: const TextStyle(
              color: Colors.white,
              fontWeight:
              FontWeight.bold,
              fontSize: 16,
            ),
          ),

          const SizedBox(
            height: 4,
          ),

          Text(
            title,
            textAlign:
            TextAlign.center,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}