import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class NotificationDetailCard extends StatelessWidget {
  final String title;

  final String message;

  final String type;

  final DateTime createdAt;

  final String? orderNumber;

  final bool isRead;

  const NotificationDetailCard({
    super.key,
    required this.title,
    required this.message,
    required this.type,
    required this.createdAt,
    required this.isRead,
    this.orderNumber,
  });

  @override
  Widget build(BuildContext context) {
    final icon = _getNotificationIcon();

    final color = _getNotificationColor();

    return Container(
      padding: const EdgeInsets.all(
        20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),
            blurRadius: 16,
            offset: const Offset(
              0,
              8,
            ),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment:
            CrossAxisAlignment.start,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration:
                BoxDecoration(
                  color: color
                      .withOpacity(
                    0.10,
                  ),
                  borderRadius:
                  BorderRadius
                      .circular(
                    16,
                  ),
                ),
                child: Icon(
                  icon,
                  color: color,
                  size: 30,
                ),
              ),

              const SizedBox(
                width: 16,
              ),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment
                      .start,
                  children: [
                    Text(
                      title,
                      style:
                      const TextStyle(
                        fontSize: 18,
                        fontWeight:
                        FontWeight
                            .bold,
                        color: AppTheme
                            .textPrimary,
                      ),
                    ),

                    const SizedBox(
                      height: 6,
                    ),

                    Text(
                      type,
                      style:
                      TextStyle(
                        color:
                        color,
                        fontWeight:
                        FontWeight
                            .w600,
                      ),
                    ),
                  ],
                ),
              ),

              _buildStatusChip(),
            ],
          ),

          const SizedBox(
            height: 24,
          ),

          const Text(
            'Message',
            style: TextStyle(
              fontWeight:
              FontWeight.bold,
              fontSize: 16,
            ),
          ),

          const SizedBox(
            height: 10,
          ),

          Text(
            message,
            style: const TextStyle(
              color:
              AppTheme.textSecondary,
              fontSize: 15,
              height: 1.5,
            ),
          ),

          if (orderNumber != null &&
              orderNumber!
                  .isNotEmpty) ...[
            const SizedBox(
              height: 24,
            ),

            Container(
              padding:
              const EdgeInsets
                  .all(
                16,
              ),
              decoration:
              BoxDecoration(
                color: AppTheme
                    .primaryColor
                    .withOpacity(
                  0.08,
                ),
                borderRadius:
                BorderRadius.circular(
                  14,
                ),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons
                        .receipt_long,
                    color: AppTheme
                        .primaryColor,
                  ),

                  const SizedBox(
                    width: 12,
                  ),

                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment
                          .start,
                      children: [
                        const Text(
                          'Related Order',
                          style:
                          TextStyle(
                            color: AppTheme
                                .textSecondary,
                            fontSize:
                            13,
                          ),
                        ),

                        const SizedBox(
                          height: 4,
                        ),

                        Text(
                          orderNumber!,
                          style:
                          const TextStyle(
                            fontWeight:
                            FontWeight
                                .bold,
                            fontSize:
                            16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(
            height: 24,
          ),

          Row(
            children: [
              const Icon(
                Icons.access_time,
                size: 18,
                color: AppTheme
                    .textSecondary,
              ),

              const SizedBox(
                width: 8,
              ),

              Expanded(
                child: Text(
                  _formatDate(
                    createdAt,
                  ),
                  style:
                  const TextStyle(
                    color: AppTheme
                        .textSecondary,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatusChip() {
    return Container(
      padding:
      const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: isRead
            ? Colors.grey
            .withOpacity(
            0.12)
            : Colors.blue
            .withOpacity(
            0.12),
        borderRadius:
        BorderRadius.circular(
          20,
        ),
      ),
      child: Text(
        isRead
            ? 'Read'
            : 'Unread',
        style: TextStyle(
          color: isRead
              ? Colors.grey
              : Colors.blue,
          fontWeight:
          FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  IconData
  _getNotificationIcon() {
    switch (type
        .toLowerCase()) {
      case 'job':
        return Icons.work;

      case 'bonus':
        return Icons
            .workspace_premium;

      case 'payment':
        return Icons.payments;

      case 'warning':
        return Icons.warning;

      case 'system':
        return Icons.settings;

      default:
        return Icons
            .notifications;
    }
  }

  Color
  _getNotificationColor() {
    switch (type
        .toLowerCase()) {
      case 'job':
        return Colors.blue;

      case 'bonus':
        return Colors.orange;

      case 'payment':
        return Colors.green;

      case 'warning':
        return Colors.red;

      case 'system':
        return Colors.purple;

      default:
        return AppTheme
            .primaryColor;
    }
  }

  String _formatDate(
      DateTime date,
      ) {
    final day =
    date.day
        .toString()
        .padLeft(
      2,
      '0',
    );

    final month =
    date.month
        .toString()
        .padLeft(
      2,
      '0',
    );

    final year =
        date.year;

    final hour =
    date.hour
        .toString()
        .padLeft(
      2,
      '0',
    );

    final minute =
    date.minute
        .toString()
        .padLeft(
      2,
      '0',
    );

    return '$day/$month/$year • $hour:$minute';
  }
}