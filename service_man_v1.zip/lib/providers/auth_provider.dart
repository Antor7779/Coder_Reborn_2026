import 'package:flutter/material.dart';

import '../mock/demo_auth_service.dart';
import '../models/worker.dart';

class AuthProvider extends ChangeNotifier {
  Worker? _currentWorker;

  bool _isLoading = false;

  bool _isAuthenticated = false;

  String? _errorMessage;

  // Getters

  Worker? get currentWorker => _currentWorker;

  bool get isLoading => _isLoading;

  bool get isAuthenticated => _isAuthenticated;

  String? get errorMessage => _errorMessage;

  bool get hasUser => _currentWorker != null;

  // Initialize authentication state

  Future<void> initialize() async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 500,
        ),
      );

      final restored =
      await DemoAuthService
          .restoreSession();

      if (restored) {
        _currentWorker =
            DemoAuthService.currentUser;

        _isAuthenticated =
            _currentWorker != null;
      } else {
        _currentWorker = null;

        _isAuthenticated = false;
      }

      _errorMessage = null;
    } catch (e) {
      _errorMessage =
      'Failed to initialize authentication.';
    } finally {
      _setLoading(false);
    }
  }

  // Login

  Future<bool> login({
    required String email,
    required String password,
  }) async {
    try {
      _setLoading(true);

      _errorMessage = null;

      await Future.delayed(
        const Duration(milliseconds: 800),
      );

      final worker =
      await DemoAuthService.login(
        email: email,
        password: password,
      );

      if (worker == null) {
        _errorMessage =
        'Invalid email or password.';

        _isAuthenticated = false;

        notifyListeners();

        return false;
      }

      _currentWorker = worker;

      _isAuthenticated = true;

      notifyListeners();

      return true;
    } catch (e) {
      _errorMessage =
      'Login failed. Please try again.';

      _isAuthenticated = false;

      notifyListeners();

      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Register

  Future<bool> register({
    required Worker worker,
    required String password,
  }) async {
    try {
      _setLoading(true);

      _errorMessage = null;

      await Future.delayed(
        const Duration(milliseconds: 1000),
      );

      final success =
      await DemoAuthService.register(
        worker: worker,
        password: password,
      );

      if (!success) {
        _errorMessage =
        'Registration failed.';

        notifyListeners();

        return false;
      }

      return true;
    } catch (e) {
      _errorMessage =
      'Unable to register account.';

      notifyListeners();

      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Logout

  Future<void> logout() async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(milliseconds: 400),
      );

      await DemoAuthService.logout();

      _currentWorker = null;

      _isAuthenticated = false;

      _errorMessage = null;

      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  // Refresh current user

  Future<void> refreshUser() async {
    try {
      if (!_isAuthenticated) {
        return;
      }

      _setLoading(true);

      await Future.delayed(
        const Duration(milliseconds: 400),
      );

      _currentWorker =
          DemoAuthService.currentUser;

      notifyListeners();
    } finally {
      _setLoading(false);
    }
  }

  // Update worker profile

  Future<bool> updateProfile(
      Worker updatedWorker,
      ) async {
    try {
      _setLoading(true);

      _errorMessage = null;

      final success =
      await DemoAuthService
          .updateProfile(
        updatedWorker,
      );

      if (!success) {
        _errorMessage =
        'Failed to update profile.';

        notifyListeners();

        return false;
      }

      _currentWorker =
          updatedWorker;

      notifyListeners();

      return true;
    } catch (e) {
      _errorMessage =
      'Unable to update profile.';

      notifyListeners();

      return false;
    } finally {
      _setLoading(false);
    }
  }

  // Update user locally

  void updateWorker(
      Worker worker,
      ) {
    _currentWorker = worker;

    notifyListeners();
  }

  // Clear error

  void clearError() {
    _errorMessage = null;

    notifyListeners();
  }

  void _setLoading(
      bool value,
      ) {
    _isLoading = value;

    notifyListeners();
  }
}