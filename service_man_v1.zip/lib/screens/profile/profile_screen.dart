
import 'package:flutter/material.dart';

import '../../app/theme.dart';

class ProfileScreen extends StatelessWidget {
const ProfileScreen({
super.key,
});

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: AppTheme.scaffoldColor,

appBar: AppBar(
title: const Text(
'My Profile',
),
),

body: SingleChildScrollView(
padding: const EdgeInsets.all(
20,
),

child: Column(
children: [
_buildProfileHeader(),

const SizedBox(
height: 24,
),

_buildVerificationCard(),

const SizedBox(
height: 24,
),

_buildPersonalInfo(),

const SizedBox(
height: 24,
),

_buildProfessionalInfo(),

const SizedBox(
height: 24,
),

_buildPerformanceSection(),

const SizedBox(
height: 24,
),

_buildActionButtons(
context,
),

const SizedBox(
height: 40,
),
],
),
),
);
}

Widget _buildProfileHeader() {
return Container(
padding: const EdgeInsets.all(
24,
),

decoration: BoxDecoration(
gradient: const LinearGradient(
colors: [
AppTheme.primaryColor,
AppTheme.primaryDarkColor,
],
),

borderRadius:
BorderRadius.circular(
28,
),
),

child: Column(
children: [
Stack(
children: [
const CircleAvatar(
radius: 55,

backgroundColor:
Colors.white,

child: Icon(
Icons.person,

size: 60,

color: AppTheme
    .primaryColor,
),
),

Positioned(
right: 0,
bottom: 0,
child: Container(
padding:
const EdgeInsets
    .all(
6,
),

decoration:
const BoxDecoration(
color:
Colors.green,

shape:
BoxShape
    .circle,
),

child: const Icon(
Icons.verified,

color:
Colors.white,

size: 20,
),
),
),
],
),

const SizedBox(
height: 16,
),

const Text(
'Antor Shardar',

style: TextStyle(
color: Colors.white,

fontSize: 28,

fontWeight:
FontWeight.bold,
),
),

const SizedBox(
height: 8,
),

const Text(
'Service Partner',

style: TextStyle(
color: Colors.white70,

fontSize: 16,
),
),

const SizedBox(
height: 16,
),

Container(
padding:
const EdgeInsets
    .symmetric(
horizontal: 14,
vertical: 10,
),

decoration:
BoxDecoration(
color: Colors.white
    .withOpacity(
0.15,
),

borderRadius:
BorderRadius
    .circular(
18,
),
),

child: const Row(
mainAxisSize:
MainAxisSize.min,

children: [
Icon(
Icons.star,

color:
Colors.amber,
),

SizedBox(
width: 8,
),

Text(
'4.9 Rating',

style:
TextStyle(
color:
Colors
    .white,

fontWeight:
FontWeight
    .bold,
),
),
],
),
),
],
),
);
}

Widget _buildVerificationCard() {
return Container(
padding: const EdgeInsets.all(
20,
),

decoration: BoxDecoration(
color: Colors.white,

borderRadius:
BorderRadius.circular(
24,
),
),

child: Column(
crossAxisAlignment:
CrossAxisAlignment
    .start,

children: [
const Text(
'Verification Status',

style: TextStyle(
fontSize: 18,

fontWeight:
FontWeight.bold,
),
),

const SizedBox(
height: 20,
),

_verificationItem(
'Selfie Verification',
true,
),

_verificationItem(
'NID Verification',
true,
),

_verificationItem(
'Phone Verification',
true,
),

_verificationItem(
'Address Verification',
false,
),
],
),
);
}

Widget _verificationItem(
String title,
bool verified,
) {
return Padding(
padding:
const EdgeInsets.only(
bottom: 16,
),

child: Row(
children: [
Icon(
verified
? Icons
    .check_circle
    : Icons
    .radio_button_unchecked,

color: verified
? Colors.green
    : Colors.grey,
),

const SizedBox(
width: 12,
),

Expanded(
child: Text(
title,
),
),

Text(
verified
? 'Verified'
    : 'Pending',

style: TextStyle(
color: verified
? Colors.green
    : Colors.orange,

fontWeight:
FontWeight.bold,
),
),
],
),
);
}

Widget _buildPersonalInfo() {
return _sectionCard(
title:
'Personal Information',

children: const [
ListTile(
leading:
Icon(Icons.email),

title:
Text('Email'),

subtitle: Text(
'antor@example.com',
),
),

ListTile(
leading:
Icon(Icons.phone),

title:
Text('Phone'),

subtitle:
Text(
'017XXXXXXXX',
),
),

ListTile(
leading:
Icon(Icons.location_on),

title:
Text('Address'),

subtitle: Text(
'Dhaka, Bangladesh',
),
),
],
);
}

Widget _buildProfessionalInfo() {
return _sectionCard(
title:
'Professional Information',

children: const [
ListTile(
leading:
Icon(Icons.build),

title:
Text('Skills'),

subtitle: Text(
'AC Service, Electrical Repair',
),
),

ListTile(
leading:
Icon(Icons.work),

title:
Text(
'Experience',
),

subtitle: Text(
'5 Years',
),
),

ListTile(
leading:
Icon(Icons.workspace_premium),

title:
Text(
'Current Tier',
),

subtitle:
Text('Gold'),
),
],
);
}

Widget _buildPerformanceSection() {
return Container(
padding: const EdgeInsets.all(
20,
),

decoration: BoxDecoration(
color: Colors.white,

borderRadius:
BorderRadius.circular(
24,
),
),

child: Column(
crossAxisAlignment:
CrossAxisAlignment
    .start,

children: [
const Text(
'Performance',

style: TextStyle(
fontSize: 18,

fontWeight:
FontWeight.bold,
),
),

const SizedBox(
height: 20,
),

const LinearProgressIndicator(
value: 0.75,

minHeight: 12,
),

const SizedBox(
height: 12,
),

const Text(
'750 / 1000 points to Platinum Tier',
),

const SizedBox(
height: 20,
),

Row(
children: [
Expanded(
child: _performanceItem(
'Completed',
'127',
),
),

Expanded(
child: _performanceItem(
'Points',
'750',
),
),

Expanded(
child: _performanceItem(
'Rating',
'4.9',
),
),
],
),
],
),
);
}

Widget _performanceItem(
String title,
String value,
) {
return Column(
children: [
Text(
value,

style: const TextStyle(
fontSize: 24,

fontWeight:
FontWeight.bold,
),
),

const SizedBox(
height: 6,
),

Text(title),
],
);
}

Widget _buildActionButtons(
BuildContext context,
) {
return Column(
children: [
SizedBox(
width: double.infinity,

child: ElevatedButton.icon(
onPressed: () {},

icon: const Icon(
Icons.edit,
),

label: const Text(
'Edit Profile',
),
),
),

const SizedBox(
height: 16,
),

SizedBox(
width: double.infinity,

child: OutlinedButton.icon(
onPressed: () {},

icon: const Icon(
Icons.logout,
),

label: const Text(
'Logout',
),
),
),
],
);
}

Widget _sectionCard({
required String title,
required List<Widget> children,
}) {
return Container(
padding: const EdgeInsets.all(
20,
),

decoration: BoxDecoration(
color: Colors.white,

borderRadius:
BorderRadius.circular(
24,
),
),

child: Column(
crossAxisAlignment:
CrossAxisAlignment
    .start,

children: [
Text(
title,

style: const TextStyle(
fontSize: 18,

fontWeight:
FontWeight.bold,
),
),

const SizedBox(
height: 12,
),

...children,
],
),
);
}
}

