import 'package:flutter/material.dart';

class WorkerNotification {
  /// Unique notification ID
  final int id;

  /// Notification title
  final String title;

  /// Notification message
  final String message;

  /// Notification type
  ///
  /// new_job
  /// bonus_job
  /// payment
  /// cancelled_job
  /// rating
  /// verification
  /// system
  final String type;

  /// Icon displayed in UI
  final IconData icon;

  /// Read status
  final bool isRead;

  /// Creation time
  final DateTime createdAt;

  /// Optional action data
  final int? relatedJobId;

  final String? orderNumber;

  /// Whether tapping notification should navigate somewhere
  final bool hasAction;

  /// Route name for future navigation
  final String? route;

  const WorkerNotification({
    required this.id,
    required this.title,
    required this.message,
    required this.type,
    required this.icon,
    required this.isRead,
    required this.createdAt,
    required this.relatedJobId,
    required this.orderNumber,
    required this.hasAction,
    required this.route,
  });

  WorkerNotification copyWith({
    int? id,
    String? title,
    String? message,
    String? type,
    IconData? icon,
    bool? isRead,
    DateTime? createdAt,
    int? relatedJobId,
    String? orderNumber,
    bool? hasAction,
    String? route,
  }) {
    return WorkerNotification(
      id: id ?? this.id,
      title: title ?? this.title,
      message: message ?? this.message,
      type: type ?? this.type,
      icon: icon ?? this.icon,
      isRead: isRead ?? this.isRead,
      createdAt: createdAt ?? this.createdAt,
      relatedJobId: relatedJobId ?? this.relatedJobId,
      orderNumber: orderNumber ?? this.orderNumber,
      hasAction: hasAction ?? this.hasAction,
      route: route ?? this.route,
    );
  }

  // Notification type helpers

  bool get isNewJob => type.toLowerCase() == 'new_job';

  bool get isBonusJob => type.toLowerCase() == 'bonus_job';

  bool get isPayment => type.toLowerCase() == 'payment';

  bool get isCancelledJob => type.toLowerCase() == 'cancelled_job';

  bool get isRating => type.toLowerCase() == 'rating';

  bool get isVerification => type.toLowerCase() == 'verification';

  bool get isSystem => type.toLowerCase() == 'system';

  // Read status helpers

  bool get unread => !isRead;

  bool get read => isRead;

  // Time Ago Helper

  String get timeAgo {
    final difference = DateTime.now().difference(createdAt);

    if (difference.inSeconds < 60) {
      return 'Just now';
    }

    if (difference.inMinutes < 60) {
      return '${difference.inMinutes}m ago';
    }

    if (difference.inHours < 24) {
      return '${difference.inHours}h ago';
    }

    if (difference.inDays < 7) {
      return '${difference.inDays}d ago';
    }

    if (difference.inDays < 30) {
      return '${(difference.inDays / 7).floor()}w ago';
    }

    if (difference.inDays < 365) {
      return '${(difference.inDays / 30).floor()}mo ago';
    }

    return '${(difference.inDays / 365).floor()}y ago';
  }

  // UI helper

  Color get notificationColor {
    switch (type.toLowerCase()) {
      case 'new_job':
        return Colors.blue;

      case 'bonus_job':
        return Colors.orange;

      case 'payment':
        return Colors.green;

      case 'cancelled_job':
        return Colors.red;

      case 'rating':
        return Colors.amber;

      case 'verification':
        return Colors.purple;

      default:
        return Colors.grey;
    }
  }
}