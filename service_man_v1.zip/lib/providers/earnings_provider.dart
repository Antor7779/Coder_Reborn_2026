import 'package:flutter/material.dart';

import '../mock/demo_wallet.dart';
import '../models/wallet.dart';
import '../models/wallet_transaction.dart';
class EarningsProvider extends ChangeNotifier {
  Wallet? _wallet;

  bool _isLoading = false;

  String? _errorMessage;

  Wallet? get wallet => _wallet;

  bool get isLoading => _isLoading;

  String? get errorMessage => _errorMessage;

  bool get hasWallet => _wallet != null;

  double get availableBalance =>
      _wallet?.availableBalance ?? 0;

  double get todayEarnings =>
      _wallet?.todayEarnings ?? 0;

  double get bonusEarned =>
      _wallet?.bonusEarned ?? 0;

  double get totalWithdrawn =>
      _wallet?.totalWithdrawn ?? 0;

  double get monthlyGoal =>
      _wallet?.monthlyGoal ?? 0;

  double get monthlyEarnings =>
      _wallet?.monthlyEarnings ?? 0;

  List<WalletTransaction>
  get transactions =>
      _wallet?.transactions ?? [];

  double get goalProgress {
    if (_wallet == null ||
        monthlyGoal == 0) {
      return 0;
    }

    return monthlyEarnings /
        monthlyGoal;
  }

  Future<void> initialize() async {
    try {
      _setLoading(true);

      await Future.delayed(
        const Duration(
          milliseconds: 500,
        ),
      );

      _wallet =
          DemoWallet.wallet;

      _errorMessage = null;
    } catch (e) {
      _errorMessage =
      'Failed to load wallet.';
    } finally {
      _setLoading(false);
    }
  }

  Future<void> refreshWallet() async {
    await initialize();
  }

  Future<bool> withdraw(
      double amount,
      ) async {
    try {
      if (_wallet == null) {
        return false;
      }

      if (amount <= 0) {
        _errorMessage =
        'Invalid withdrawal amount.';

        notifyListeners();

        return false;
      }

      if (amount >
          availableBalance) {
        _errorMessage =
        'Insufficient balance.';

        notifyListeners();

        return false;
      }

      _setLoading(true);

      await Future.delayed(
        const Duration(
          seconds: 1,
        ),
      );

      final updatedTransactions =
      List<
          WalletTransaction>.from(
        transactions,
      );

      updatedTransactions.insert(
        0,
        WalletTransaction(
          id: DateTime.now()
              .millisecondsSinceEpoch,

          title: 'Withdrawal',

          description:
          'Money withdrawn from wallet',

          amount: amount,

          type: 'debit',

          createdAt: DateTime.now(),
        ),
      );

      _wallet =
          _wallet!.copyWith(
            availableBalance:
            availableBalance -
                amount,

            totalWithdrawn:
            totalWithdrawn +
                amount,

            transactions:
            updatedTransactions,
          );

      _errorMessage = null;

      notifyListeners();

      return true;
    } catch (e) {
      _errorMessage =
      'Withdrawal failed.';

      notifyListeners();

      return false;
    } finally {
      _setLoading(false);
    }
  }

  void addEarnings({
    required double amount,
    double bonus = 0,
    String title =
    'Completed Service',
  }) {
    if (_wallet == null) {
      return;
    }

    final updatedTransactions =
    List<
        WalletTransaction>.from(
      transactions,
    );

    updatedTransactions.insert(
      0,
      WalletTransaction(
        id: DateTime.now()
            .millisecondsSinceEpoch,

        title: 'Withdrawal',

        description:
        'Money withdrawn from wallet',

        amount: amount,

        type: 'debit',

        createdAt: DateTime.now(),
      ),
    );

    _wallet = _wallet!.copyWith(
      availableBalance:
      availableBalance +
          amount +
          bonus,

      todayEarnings:
      todayEarnings +
          amount,

      bonusEarned:
      bonusEarned +
          bonus,

      monthlyEarnings:
      monthlyEarnings +
          amount +
          bonus,

      transactions:
      updatedTransactions,
    );

    notifyListeners();
  }

  void updateMonthlyGoal(
      double goal,
      ) {
    if (_wallet == null) {
      return;
    }

    _wallet =
        _wallet!.copyWith(
          monthlyGoal: goal,
        );

    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;

    notifyListeners();
  }

  void clearWallet() {
    _wallet = null;

    notifyListeners();
  }

  void _setLoading(
      bool value,
      ) {
    _isLoading = value;

    notifyListeners();
  }
}