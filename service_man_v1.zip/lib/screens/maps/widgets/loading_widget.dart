import 'package:flutter/material.dart';

import '../core/themes/app_theme.dart';

class LoadingWidget extends StatelessWidget {
  final String title;
  final String? subtitle;
  final bool showCard;

  const LoadingWidget({
    super.key,
    this.title = 'Getting your location...',
    this.subtitle =
    'Please wait while we acquire a GPS signal.',
    this.showCard = true,
  });

  @override
  Widget build(BuildContext context) {
    final content = Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          width: 70,
          height: 70,
          child: CircularProgressIndicator(
            strokeWidth: 6,
          ),
        ),

        const SizedBox(height: 24),

        Text(
          title,
          textAlign: TextAlign.center,
          style: Theme.of(context)
              .textTheme
              .titleLarge
              ?.copyWith(
            fontWeight: FontWeight.w700,
          ),
        ),

        if (subtitle != null) ...[
          const SizedBox(height: 12),

          Text(
            subtitle!,
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(
              color: Colors.grey.shade600,
              height: 1.4,
            ),
          ),
        ],
      ],
    );

    if (!showCard) {
      return Center(
        child: Padding(
          padding:
          const EdgeInsets.all(24),
          child: content,
        ),
      );
    }

    return Center(
      child: Padding(
        padding:
        const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints:
          const BoxConstraints(
            maxWidth: 420,
          ),
          child: Card(
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius:
              BorderRadius.circular(24),
            ),
            child: Padding(
              padding:
              const EdgeInsets.all(32),
              child: content,
            ),
          ),
        ),
      ),
    );
  }
}

/// Full-screen loading overlay.
///
/// Useful when you want to block user
/// interaction during initialization.
class FullScreenLoadingOverlay
    extends StatelessWidget {
  final String title;
  final String? subtitle;

  const FullScreenLoadingOverlay({
    super.key,
    this.title =
    'Preparing tracker...',
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Theme.of(context)
          .scaffoldBackgroundColor,
      child: LoadingWidget(
        title: title,
        subtitle: subtitle,
      ),
    );
  }
}

/// Small inline loader for buttons,
/// cards, or compact UI sections.
class CompactLoadingIndicator
    extends StatelessWidget {
  final double size;

  const CompactLoadingIndicator({
    super.key,
    this.size = 24,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child:
      const CircularProgressIndicator(
        strokeWidth: 3,
      ),
    );
  }
}