import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class QuickActionTile extends StatelessWidget {
  final String title;

  final String subtitle;

  final IconData icon;

  final Color? iconColor;

  final VoidCallback? onTap;

  final bool showBadge;

  final String? badgeText;

  const QuickActionTile({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.iconColor,
    this.onTap,
    this.showBadge = false,
    this.badgeText,
  });

  @override
  Widget build(BuildContext context) {
    final color =
        iconColor ??
            AppTheme.primaryColor;

    return Material(
      color: Colors.transparent,

      child: InkWell(
        onTap: onTap,

        borderRadius:
        BorderRadius.circular(
          24,
        ),

        child: Ink(
          padding:
          const EdgeInsets.all(
            18,
          ),

          decoration:
          BoxDecoration(
            color: Colors.white,

            borderRadius:
            BorderRadius.circular(
              24,
            ),

            boxShadow: [
              BoxShadow(
                color: Colors.black
                    .withOpacity(
                  0.05,
                ),

                blurRadius: 16,

                offset:
                const Offset(
                  0,
                  8,
                ),
              ),
            ],
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,

            children: [
              Row(
                children: [
                  Container(
                    width: 52,

                    height: 52,

                    decoration:
                    BoxDecoration(
                      color: color
                          .withOpacity(
                        0.12,
                      ),

                      borderRadius:
                      BorderRadius
                          .circular(
                        16,
                      ),
                    ),

                    child: Icon(
                      icon,

                      color: color,

                      size: 28,
                    ),
                  ),

                  const Spacer(),

                  if (showBadge)
                    Container(
                      padding:
                      const EdgeInsets
                          .symmetric(
                        horizontal:
                        10,

                        vertical: 4,
                      ),

                      decoration:
                      BoxDecoration(
                        color: Colors
                            .red,

                        borderRadius:
                        BorderRadius
                            .circular(
                          12,
                        ),
                      ),

                      child: Text(
                        badgeText ??
                            'New',

                        style:
                        const TextStyle(
                          color: Colors
                              .white,

                          fontSize:
                          11,

                          fontWeight:
                          FontWeight
                              .bold,
                        ),
                      ),
                    ),
                ],
              ),

              const Spacer(),

              Text(
                title,

                style:
                const TextStyle(
                  fontSize: 17,

                  fontWeight:
                  FontWeight
                      .w700,

                  color: AppTheme
                      .textPrimary,
                ),
              ),

              const SizedBox(
                height: 6,
              ),

              Text(
                subtitle,

                maxLines: 2,

                overflow:
                TextOverflow
                    .ellipsis,

                style:
                const TextStyle(
                  fontSize: 13,

                  color: AppTheme
                      .textSecondary,

                  height: 1.4,
                ),
              ),

              const SizedBox(
                height: 14,
              ),

              Row(
                children: [
                  Text(
                    'Open',

                    style:
                    TextStyle(
                      color: color,

                      fontWeight:
                      FontWeight
                          .bold,
                    ),
                  ),

                  const SizedBox(
                    width: 6,
                  ),

                  Icon(
                    Icons
                        .arrow_forward_rounded,

                    size: 18,

                    color: color,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}