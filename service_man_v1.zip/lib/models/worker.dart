class Worker {
  final int id;

  final String fullName;

  final String mobile;

  final String email;

  /// Authentication password
  final String password;

  final String address;

  final double latitude;

  final double longitude;

  final String profileImage;

  final String nidNumber;

  final String nidFrontImage;

  final String nidBackImage;

  final String tradeCategory;

  final int experienceYears;

  final List<String> skills;

  final double rating;

  final int totalJobsCompleted;

  final int points;

  final String tier;

  final double walletBalance;

  final double bonusBalance;

  final bool isVerified;

  final bool faceVerified;

  final bool nidVerified;

  final DateTime joinedAt;

  const Worker({
    required this.id,
    required this.fullName,
    required this.mobile,
    required this.email,
    required this.password,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.profileImage,
    required this.nidNumber,
    required this.nidFrontImage,
    required this.nidBackImage,
    required this.tradeCategory,
    required this.experienceYears,
    required this.skills,
    required this.rating,
    required this.totalJobsCompleted,
    required this.points,
    required this.tier,
    required this.walletBalance,
    required this.bonusBalance,
    required this.isVerified,
    required this.faceVerified,
    required this.nidVerified,
    required this.joinedAt,
  });

  Worker copyWith({
    int? id,
    String? fullName,
    String? mobile,
    String? email,
    String? password,
    String? address,
    double? latitude,
    double? longitude,
    String? profileImage,
    String? nidNumber,
    String? nidFrontImage,
    String? nidBackImage,
    String? tradeCategory,
    int? experienceYears,
    List<String>? skills,
    double? rating,
    int? totalJobsCompleted,
    int? points,
    String? tier,
    double? walletBalance,
    double? bonusBalance,
    bool? isVerified,
    bool? faceVerified,
    bool? nidVerified,
    DateTime? joinedAt,
  }) {
    return Worker(
      id: id ?? this.id,
      fullName: fullName ?? this.fullName,
      mobile: mobile ?? this.mobile,
      email: email ?? this.email,
      password: password ?? this.password,
      address: address ?? this.address,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      profileImage: profileImage ?? this.profileImage,
      nidNumber: nidNumber ?? this.nidNumber,
      nidFrontImage: nidFrontImage ?? this.nidFrontImage,
      nidBackImage: nidBackImage ?? this.nidBackImage,
      tradeCategory: tradeCategory ?? this.tradeCategory,
      experienceYears:
      experienceYears ?? this.experienceYears,
      skills: skills ?? this.skills,
      rating: rating ?? this.rating,
      totalJobsCompleted:
      totalJobsCompleted ??
          this.totalJobsCompleted,
      points: points ?? this.points,
      tier: tier ?? this.tier,
      walletBalance:
      walletBalance ?? this.walletBalance,
      bonusBalance:
      bonusBalance ?? this.bonusBalance,
      isVerified:
      isVerified ?? this.isVerified,
      faceVerified:
      faceVerified ?? this.faceVerified,
      nidVerified:
      nidVerified ?? this.nidVerified,
      joinedAt: joinedAt ?? this.joinedAt,
    );
  }

  /// Tier helpers
  bool get isBronzeTier =>
      tier.toLowerCase() == 'bronze';

  bool get isSilverTier =>
      tier.toLowerCase() == 'silver';

  bool get isGoldTier =>
      tier.toLowerCase() == 'gold';

  bool get isPlatinumTier =>
      tier.toLowerCase() == 'platinum';

  bool get isDiamondTier =>
      tier.toLowerCase() == 'diamond';

  /// Verification helpers
  bool get isFullyVerified =>
      isVerified &&
          faceVerified &&
          nidVerified;

  /// Wallet helpers
  double get totalEarnings =>
      walletBalance + bonusBalance;

  /// Experience helpers
  bool get isExperienced =>
      experienceYears >= 5;

  /// Display helpers
  String get displayName =>
      fullName.trim();

  String get initials {
    final parts = fullName.trim().split(' ');

    if (parts.isEmpty) {
      return '';
    }

    if (parts.length == 1) {
      return parts.first[0].toUpperCase();
    }

    return '${parts.first[0]}${parts.last[0]}'
        .toUpperCase();
  }

  /// Performance helpers
  bool get isTopRated =>
      rating >= 4.5;

  bool get hasCompletedJobs =>
      totalJobsCompleted > 0;
}