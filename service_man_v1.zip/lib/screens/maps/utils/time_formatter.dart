import 'package:intl/intl.dart';

class TimeFormatter {
  TimeFormatter._();

  /// Example:
  /// 14 Jun 2026 • 09:42:31 PM
  static String formatFull(DateTime dateTime) {
    return DateFormat(
      'dd MMM yyyy • hh:mm:ss a',
    ).format(dateTime);
  }

  /// Example:
  /// 14 Jun 2026
  static String formatDate(DateTime dateTime) {
    return DateFormat(
      'dd MMM yyyy',
    ).format(dateTime);
  }

  /// Example:
  /// 09:42 PM
  static String formatTime(DateTime dateTime) {
    return DateFormat(
      'hh:mm a',
    ).format(dateTime);
  }

  /// Example:
  /// 09:42:31 PM
  static String formatTimeWithSeconds(
      DateTime dateTime,
      ) {
    return DateFormat(
      'hh:mm:ss a',
    ).format(dateTime);
  }

  /// Example:
  /// Monday, 14 Jun 2026
  static String formatDayAndDate(
      DateTime dateTime,
      ) {
    return DateFormat(
      'EEEE, dd MMM yyyy',
    ).format(dateTime);
  }

  /// Example:
  /// 2 min ago
  /// 3 hrs ago
  /// Yesterday
  /// 5 days ago
  static String timeAgo(DateTime dateTime) {
    final difference =
    DateTime.now().difference(dateTime);

    if (difference.inSeconds < 60) {
      return 'Just now';
    }

    if (difference.inMinutes < 60) {
      final minutes =
          difference.inMinutes;

      return '$minutes min${minutes == 1 ? '' : 's'} ago';
    }

    if (difference.inHours < 24) {
      final hours =
          difference.inHours;

      return '$hours hr${hours == 1 ? '' : 's'} ago';
    }

    if (difference.inDays == 1) {
      return 'Yesterday';
    }

    if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    }

    return formatDate(dateTime);
  }

  /// Example:
  /// Today • 09:42 PM
  /// Yesterday • 06:10 PM
  /// 12 Jun 2026 • 08:15 AM
  static String smartFormat(
      DateTime dateTime,
      ) {
    final now = DateTime.now();

    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    final yesterday = today.subtract(
      const Duration(days: 1),
    );

    final target = DateTime(
      dateTime.year,
      dateTime.month,
      dateTime.day,
    );

    if (target == today) {
      return 'Today • ${formatTime(dateTime)}';
    }

    if (target == yesterday) {
      return 'Yesterday • ${formatTime(dateTime)}';
    }

    return formatFull(dateTime);
  }

  /// Example:
  /// 01:25:32
  static String formatDuration(
      Duration duration,
      ) {
    final hours = duration.inHours
        .toString()
        .padLeft(2, '0');

    final minutes = duration.inMinutes
        .remainder(60)
        .toString()
        .padLeft(2, '0');

    final seconds = duration.inSeconds
        .remainder(60)
        .toString()
        .padLeft(2, '0');

    return '$hours:$minutes:$seconds';
  }

  /// Example:
  /// 14/06/2026
  static String formatCompactDate(
      DateTime dateTime,
      ) {
    return DateFormat(
      'dd/MM/yyyy',
    ).format(dateTime);
  }

  /// Example:
  /// 2026-06-14 21:42:31
  static String formatForExport(
      DateTime dateTime,
      ) {
    return DateFormat(
      'yyyy-MM-dd HH:mm:ss',
    ).format(dateTime);
  }
}