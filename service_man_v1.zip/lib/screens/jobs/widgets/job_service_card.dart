import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../app/theme.dart';
import '../../../models/active_job.dart';

class JobServiceCard extends StatelessWidget {
  final ActiveJob job;

  const JobServiceCard({
    super.key,
    required this.job,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(
              alpha: 0.05,
            ),
            blurRadius: 15,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: AppTheme.primaryColor
                      .withValues(
                    alpha: 0.1,
                  ),
                  borderRadius:
                  BorderRadius.circular(
                    14,
                  ),
                ),
                child: const Icon(
                  Icons.home_repair_service,
                  color:
                  AppTheme.primaryColor,
                ),
              ),

              const SizedBox(
                width: 14,
              ),

              const Expanded(
                child: Text(
                  'Service Details',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight:
                    FontWeight.bold,
                    color: AppTheme
                        .textPrimary,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 20,
          ),

          _buildInfoRow(
            icon: Icons.build,
            title: 'Service Name',
            value: job.serviceName,
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon: Icons.category,
            title: 'Category',
            value: job.serviceCategory,
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon: Icons.description,
            title: 'Description',
            value:
            job.serviceDescription,
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon: Icons.payments,
            title: 'Service Price',
            value:
            '৳${job.servicePrice.toStringAsFixed(0)}',
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            Icons.calendar_today,
            title: 'Scheduled Date',
            value: DateFormat(
              'dd MMM yyyy • hh:mm a',
            ).format(
              job.scheduledDate,
            ),
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon: Icons.access_time,
            title:
            'Estimated Arrival',
            value:
            '${job.estimatedArrival.inMinutes} minutes',
          ),

          if (job.isCompleted &&
              job.completedAt !=
                  null) ...[
            const SizedBox(
              height: 20,
            ),

            const Divider(),

            const SizedBox(
              height: 16,
            ),

            _buildInfoRow(
              icon:
              Icons.check_circle,
              title:
              'Completed At',
              value: DateFormat(
                'dd MMM yyyy • hh:mm a',
              ).format(
                job.completedAt!,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      crossAxisAlignment:
      CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          color:
          AppTheme.textSecondary,
          size: 22,
        ),

        const SizedBox(
          width: 14,
        ),

        Expanded(
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,
            children: [
              Text(
                title,
                style:
                const TextStyle(
                  fontSize: 13,
                  color: AppTheme
                      .textSecondary,
                ),
              ),

              const SizedBox(
                height: 4,
              ),

              Text(
                value,
                style:
                const TextStyle(
                  fontSize: 15,
                  fontWeight:
                  FontWeight
                      .w600,
                  color: AppTheme
                      .textPrimary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}