import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../models/bonus_job.dart';

class BonusJobsCard extends StatelessWidget {
  final List<BonusJob> bonusJobs;

  final double totalBonusEarned;

  final ValueChanged<BonusJob>? onBonusJobTap;

  const BonusJobsCard({
    super.key,
    required this.bonusJobs,
    required this.totalBonusEarned,
    this.onBonusJobTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(
        22,
      ),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
        BorderRadius.circular(
          28,
        ),

        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),

            blurRadius: 18,

            offset: const Offset(
              0,
              8,
            ),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,

        children: [
          Row(
            children: [
              Container(
                width: 56,

                height: 56,

                decoration:
                BoxDecoration(
                  color: Colors.orange
                      .withOpacity(
                    0.12,
                  ),

                  borderRadius:
                  BorderRadius
                      .circular(
                    18,
                  ),
                ),

                child: const Icon(
                  Icons.card_giftcard,

                  color:
                  Colors.orange,

                  size: 30,
                ),
              ),

              const SizedBox(
                width: 16,
              ),

              const Expanded(
                child: Column(
                  crossAxisAlignment:
                  CrossAxisAlignment
                      .start,

                  children: [
                    Text(
                      'Bonus Opportunities',

                      style: TextStyle(
                        fontSize: 20,

                        fontWeight:
                        FontWeight
                            .bold,

                        color: AppTheme
                            .textPrimary,
                      ),
                    ),

                    SizedBox(
                      height: 4,
                    ),

                    Text(
                      'Complete side jobs to earn extra rewards.',

                      style: TextStyle(
                        color: AppTheme
                            .textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 24,
          ),

          Container(
            padding:
            const EdgeInsets.all(
              18,
            ),

            decoration:
            BoxDecoration(
              gradient:
              LinearGradient(
                colors: [
                  Colors.orange
                      .shade400,
                  Colors.deepOrange,
                ],
              ),

              borderRadius:
              BorderRadius
                  .circular(
                20,
              ),
            ),

            child: Row(
              children: [
                const Icon(
                  Icons.account_balance_wallet,

                  color:
                  Colors.white,

                  size: 30,
                ),

                const SizedBox(
                  width: 14,
                ),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,

                    children: [
                      const Text(
                        'Total Bonus Earned',

                        style:
                        TextStyle(
                          color: Colors
                              .white70,
                        ),
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      Text(
                        '৳${totalBonusEarned.toStringAsFixed(0)}',

                        style:
                        const TextStyle(
                          color: Colors
                              .white,

                          fontSize:
                          28,

                          fontWeight:
                          FontWeight
                              .w800,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(
            height: 24,
          ),

          if (bonusJobs.isEmpty)
            Container(
              padding:
              const EdgeInsets.all(
                24,
              ),

              decoration:
              BoxDecoration(
                color: Colors
                    .grey.shade50,

                borderRadius:
                BorderRadius
                    .circular(
                  20,
                ),
              ),

              child: const Center(
                child: Text(
                  'No bonus opportunities available right now.',

                  style: TextStyle(
                    color: AppTheme
                        .textSecondary,
                  ),
                ),
              ),
            )
          else
            ...bonusJobs.map(
                  (bonusJob) =>
                  Padding(
                    padding:
                    const EdgeInsets.only(
                      bottom: 14,
                    ),

                    child: InkWell(
                      borderRadius:
                      BorderRadius
                          .circular(
                        18,
                      ),

                      onTap: () =>
                          onBonusJobTap
                              ?.call(
                            bonusJob,
                          ),

                      child:
                      Container(
                        padding:
                        const EdgeInsets
                            .all(
                          16,
                        ),

                        decoration:
                        BoxDecoration(
                          color:
                          bonusJob
                              .isCompleted
                              ? Colors
                              .green
                              .withOpacity(
                            0.08,
                          )
                              : Colors
                              .grey
                              .shade50,

                          borderRadius:
                          BorderRadius
                              .circular(
                            18,
                          ),
                        ),

                        child: Row(
                          children: [
                            Icon(
                              bonusJob
                                  .isCompleted
                                  ? Icons
                                  .check_box
                                  : Icons
                                  .check_box_outline_blank,

                              color: bonusJob
                                  .isCompleted
                                  ? Colors
                                  .green
                                  : AppTheme
                                  .textSecondary,
                            ),

                            const SizedBox(
                              width: 14,
                            ),

                            Expanded(
                              child:
                              Column(
                                crossAxisAlignment:
                                CrossAxisAlignment.start,

                                children: [
                                  Text(
                                    bonusJob.title,

                                    style:
                                    const TextStyle(
                                      fontWeight:
                                      FontWeight.bold,

                                      color: AppTheme
                                          .textPrimary,
                                    ),
                                  ),

                                  const SizedBox(
                                    height:
                                    4,
                                  ),

                                  Text(
                                    bonusJob.description,

                                    style:
                                    const TextStyle(
                                      color: AppTheme
                                          .textSecondary,

                                      height:
                                      1.4,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(
                              width: 12,
                            ),

                            Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.end,

                              children: [
                                Text(
                                  '+৳${bonusJob.rewardAmount.toStringAsFixed(0)}',

                                  style:
                                  TextStyle(
                                    color: bonusJob
                                        .isCompleted
                                        ? Colors.green
                                        : Colors.orange,

                                    fontWeight:
                                    FontWeight.bold,

                                    fontSize:
                                    16,
                                  ),
                                ),

                                const SizedBox(
                                  height:
                                  4,
                                ),

                                Text(
                                  bonusJob
                                      .isCompleted
                                      ? 'Added'
                                      : 'Available',

                                  style:
                                  const TextStyle(
                                    color: AppTheme
                                        .textSecondary,

                                    fontSize:
                                    12,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
            ),
        ],
      ),
    );
  }
}