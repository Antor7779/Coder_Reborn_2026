import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../models/active_job.dart';

class JobBonusCard extends StatelessWidget {
  final ActiveJob job;

  const JobBonusCard({
    super.key,
    required this.job,
  });

  @override
  Widget build(BuildContext context) {
    final bool hasBonus =
        job.eligibleForBonus &&
            job.bonusAmount > 0;

    return Container(
      padding: const EdgeInsets.all(
        20,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black
                .withOpacity(
              0.05,
            ),
            blurRadius: 15,
            offset: const Offset(
              0,
              6,
            ),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration:
                BoxDecoration(
                  color: Colors.orange
                      .withOpacity(
                    0.12,
                  ),
                  borderRadius:
                  BorderRadius
                      .circular(
                    14,
                  ),
                ),
                child: const Icon(
                  Icons.workspace_premium,
                  color:
                  Colors.orange,
                ),
              ),

              const SizedBox(
                width: 14,
              ),

              const Expanded(
                child: Text(
                  'Bonus & Earnings',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight:
                    FontWeight.bold,
                    color: AppTheme
                        .textPrimary,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 20,
          ),

          _buildInfoRow(
            icon:
            Icons.payments_outlined,
            title:
            'Service Earnings',
            value:
            '৳${job.servicePrice.toStringAsFixed(0)}',
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            hasBonus
                ? Icons.card_giftcard
                : Icons.block,
            title:
            'Bonus Eligibility',
            value: hasBonus
                ? 'Eligible'
                : 'Not Eligible',
            valueColor: hasBonus
                ? Colors.green
                : Colors.red,
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            Icons.monetization_on,
            title:
            'Bonus Amount',
            value:
            '৳${job.bonusAmount.toStringAsFixed(0)}',
            valueColor:
            hasBonus
                ? Colors.orange
                : AppTheme
                .textSecondary,
          ),

          const SizedBox(
            height: 14,
          ),

          _buildInfoRow(
            icon:
            job.bonusClaimed
                ? Icons
                .check_circle
                : Icons
                .pending_actions,
            title:
            'Bonus Status',
            value:
            job.bonusClaimed
                ? 'Claimed'
                : 'Pending',
            valueColor:
            job.bonusClaimed
                ? Colors.green
                : Colors.orange,
          ),

          const SizedBox(
            height: 20,
          ),

          Container(
            padding:
            const EdgeInsets.all(
              16,
            ),
            decoration:
            BoxDecoration(
              gradient:
              LinearGradient(
                colors: [
                  AppTheme
                      .primaryColor
                      .withOpacity(
                    0.10,
                  ),
                  Colors.orange
                      .withOpacity(
                    0.10,
                  ),
                ],
              ),
              borderRadius:
              BorderRadius.circular(
                14,
              ),
            ),
            child: Row(
              children: [
                const Icon(
                  Icons.account_balance_wallet,
                  color: AppTheme
                      .primaryColor,
                ),

                const SizedBox(
                  width: 12,
                ),

                Expanded(
                  child: Column(
                    crossAxisAlignment:
                    CrossAxisAlignment
                        .start,
                    children: [
                      const Text(
                        'Total Potential Earnings',
                        style:
                        TextStyle(
                          fontSize:
                          13,
                          color: AppTheme
                              .textSecondary,
                        ),
                      ),

                      const SizedBox(
                        height: 4,
                      ),

                      Text(
                        '৳${job.totalEarnings.toStringAsFixed(0)}',
                        style:
                        const TextStyle(
                          fontSize:
                          22,
                          fontWeight:
                          FontWeight
                              .bold,
                          color: AppTheme
                              .textPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          if (hasBonus) ...[
            const SizedBox(
              height: 18,
            ),

            Container(
              padding:
              const EdgeInsets.all(
                14,
              ),
              decoration:
              BoxDecoration(
                color: Colors.green
                    .withOpacity(
                  0.08,
                ),
                borderRadius:
                BorderRadius.circular(
                  12,
                ),
              ),
              child: Row(
                children: const [
                  Icon(
                    Icons.emoji_events,
                    color:
                    Colors.green,
                  ),

                  SizedBox(
                    width: 10,
                  ),

                  Expanded(
                    child: Text(
                      'Complete this job successfully to receive bonus rewards.',
                      style:
                      TextStyle(
                        fontSize:
                        13,
                        fontWeight:
                        FontWeight
                            .w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String title,
    required String value,
    Color? valueColor,
  }) {
    return Row(
      children: [
        Icon(
          icon,
          size: 22,
          color: AppTheme
              .textSecondary,
        ),

        const SizedBox(
          width: 14,
        ),

        Expanded(
          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,
            children: [
              Text(
                title,
                style:
                const TextStyle(
                  fontSize: 13,
                  color: AppTheme
                      .textSecondary,
                ),
              ),

              const SizedBox(
                height: 4,
              ),

              Text(
                value,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight:
                  FontWeight.w600,
                  color: valueColor ??
                      AppTheme
                          .textPrimary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}