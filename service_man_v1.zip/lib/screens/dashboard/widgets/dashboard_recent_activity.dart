import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../models/activity_item.dart';

class DashboardRecentActivity extends StatelessWidget {
  final List<ActivityItem> notifications;

  final List<ActivityItem> completedJobs;

  final VoidCallback? onViewAllNotifications;

  final VoidCallback? onViewAllCompletedJobs;

  const DashboardRecentActivity({
    super.key,
    required this.notifications,
    required this.completedJobs,
    this.onViewAllNotifications,
    this.onViewAllCompletedJobs,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildSection(
          title: 'Recent Notifications',
          icon: Icons.notifications_outlined,
          items: notifications.take(3).toList(),
          emptyMessage: 'No recent notifications.',
          onViewAll: onViewAllNotifications,
        ),

        const SizedBox(height: 20),

        _buildSection(
          title: 'Recently Completed',
          icon: Icons.check_circle_outline,
          items: completedJobs.take(3).toList(),
          emptyMessage: 'No completed jobs yet.',
          onViewAll: onViewAllCompletedJobs,
        ),
      ],
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required List<ActivityItem> items,
    required String emptyMessage,
    VoidCallback? onViewAll,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(
          AppTheme.radiusLG,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(
              alpha: 0.05,
            ),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
        CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: AppTheme.primaryColor,
              ),

              const SizedBox(width: 12),

              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight:
                    FontWeight.bold,
                  ),
                ),
              ),

              if (onViewAll != null)
                TextButton(
                  onPressed: onViewAll,
                  child: const Text(
                    'View All',
                  ),
                ),
            ],
          ),

          const SizedBox(height: 16),

          if (items.isEmpty)
            Padding(
              padding:
              const EdgeInsets.symmetric(
                vertical: 20,
              ),
              child: Center(
                child: Text(
                  emptyMessage,
                  style: const TextStyle(
                    color: Colors.grey,
                  ),
                ),
              ),
            )
          else
            ...items.map(
                  (item) => Column(
                children: [
                  ListTile(
                    contentPadding:
                    EdgeInsets.zero,

                    leading: CircleAvatar(
                      backgroundColor:
                      item.color.withValues(
                        alpha: 0.15,
                      ),

                      child: Icon(
                        item.icon,
                        color: item.color,
                      ),
                    ),

                    title: Text(
                      item.title,
                      style:
                      const TextStyle(
                        fontWeight:
                        FontWeight.w600,
                      ),
                    ),

                    subtitle: Text(
                      item.subtitle,
                    ),

                    trailing: Text(
                      item.timeAgo,
                      style:
                      const TextStyle(
                        color: Colors.grey,
                        fontSize: 12,
                      ),
                    ),
                  ),

                  if (item != items.last)
                    const Divider(
                      height: 1,
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}