import '../models/worker.dart';

class DemoWorkers {
  static final List<Worker> workers = [
    Worker(
      id: 1,
      fullName: 'Antor Shardar',
      mobile: '01711111111',
      email: 'antor@servicelagbe.com',
      password: '123456',
      address: 'Kaliganj, Gazipur, Dhaka',
      latitude: 23.9884,
      longitude: 90.4332,
      profileImage: 'assets/images/workers/worker_1.jpg',
      nidNumber: '1993123456789',
      nidFrontImage: 'assets/images/nid/nid_front_1.jpg',
      nidBackImage: 'assets/images/nid/nid_back_1.jpg',
      tradeCategory: 'Electrical',
      experienceYears: 5,
      skills: const [
        'Electrician',
        'AC Servicing',
      ],
      rating: 4.9,
      totalJobsCompleted: 421,
      points: 12450,
      tier: 'Diamond',
      walletBalance: 85000,
      bonusBalance: 12000,
      isVerified: true,
      faceVerified: true,
      nidVerified: true,
      joinedAt: DateTime(2023, 1, 10),
    ),

    Worker(
      id: 2,
      fullName: 'Rakib Hasan',
      mobile: '01722222222',
      email: 'rakib@servicelagbe.com',
      password: '123456',
      address: 'Mirpur, Dhaka',
      latitude: 23.8223,
      longitude: 90.3654,
      profileImage: 'assets/images/workers/worker_2.jpg',
      nidNumber: '1994123456789',
      nidFrontImage: 'assets/images/nid/nid_front_2.jpg',
      nidBackImage: 'assets/images/nid/nid_back_2.jpg',
      tradeCategory: 'Home Services',
      experienceYears: 4,
      skills: const [
        'Plumbing',
        'Cleaning',
      ],
      rating: 4.7,
      totalJobsCompleted: 302,
      points: 7850,
      tier: 'Platinum',
      walletBalance: 62000,
      bonusBalance: 8000,
      isVerified: true,
      faceVerified: true,
      nidVerified: true,
      joinedAt: DateTime(2023, 3, 15),
    ),

    Worker(
      id: 3,
      fullName: 'Karim Uddin',
      mobile: '01733333333',
      email: 'karim@servicelagbe.com',
      password: '123456',
      address: 'Uttara, Dhaka',
      latitude: 23.8759,
      longitude: 90.3795,
      profileImage: 'assets/images/workers/worker_3.jpg',
      nidNumber: '1995123456789',
      nidFrontImage: 'assets/images/nid/nid_front_3.jpg',
      nidBackImage: 'assets/images/nid/nid_back_3.jpg',
      tradeCategory: 'Electrical',
      experienceYears: 2,
      skills: const [
        'Electrician',
      ],
      rating: 4.4,
      totalJobsCompleted: 141,
      points: 3250,
      tier: 'Gold',
      walletBalance: 28000,
      bonusBalance: 3500,
      isVerified: true,
      faceVerified: true,
      nidVerified: true,
      joinedAt: DateTime(2024, 1, 5),
    ),

    Worker(
      id: 4,
      fullName: 'Mizan Ahmed',
      mobile: '01744444444',
      email: 'mizan@servicelagbe.com',
      password: '123456',
      address: 'Mohammadpur, Dhaka',
      latitude: 23.7581,
      longitude: 90.3588,
      profileImage: 'assets/images/workers/worker_4.jpg',
      nidNumber: '1996123456789',
      nidFrontImage: 'assets/images/nid/nid_front_4.jpg',
      nidBackImage: 'assets/images/nid/nid_back_4.jpg',
      tradeCategory: 'Cleaning',
      experienceYears: 3,
      skills: const [
        'Deep Cleaning',
        'Painting',
      ],
      rating: 4.2,
      totalJobsCompleted: 95,
      points: 1580,
      tier: 'Silver',
      walletBalance: 18000,
      bonusBalance: 1200,
      isVerified: true,
      faceVerified: true,
      nidVerified: true,
      joinedAt: DateTime(2024, 6, 10),
    ),
  ];

  static Worker? currentWorker;

  static Worker? findByEmailOrPhone(String login) {
    try {
      return workers.firstWhere(
            (worker) =>
        worker.email.toLowerCase() == login.toLowerCase() ||
            worker.mobile == login,
      );
    } catch (_) {
      return null;
    }
  }

  static Worker? findById(int id) {
    try {
      return workers.firstWhere(
            (worker) => worker.id == id,
      );
    } catch (_) {
      return null;
    }
  }

  /// Added for compatibility with WorkerProvider
  static Worker? getById(int id) {
    return findById(id);
  }

  static void setCurrentWorker(Worker worker) {
    currentWorker = worker;
  }

  static void logout() {
    currentWorker = null;
  }

  static bool authenticate(
      String login,
      String password,
      ) {
    final worker = findByEmailOrPhone(login);

    if (worker == null) {
      return false;
    }

    if (worker.password != password) {
      return false;
    }

    currentWorker = worker;

    return true;
  }

  static bool get isLoggedIn => currentWorker != null;
}