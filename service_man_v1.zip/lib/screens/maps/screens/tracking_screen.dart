import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';

import '../core/constants/map_constants.dart';
import '../providers/tracking_provider.dart';
import '../widgets/loading_widget.dart';
import '../widgets/location_info_card.dart';
import '../widgets/recenter_button.dart';
import '../widgets/tracking_marker.dart';

class TrackingScreen extends StatefulWidget {
  const TrackingScreen({super.key});

  @override
  State<TrackingScreen> createState() =>
      _TrackingScreenState();
}

class _TrackingScreenState
    extends State<TrackingScreen> {
  late final MapController _mapController;

  @override
  void initState() {
    super.initState();

    _mapController = MapController();

    WidgetsBinding.instance
        .addPostFrameCallback((_) {
      context
          .read<TrackingProvider>()
          .startTracking();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<TrackingProvider>(
      builder: (
          context,
          provider,
          child,
          ) {
        // Loading state
        if (provider.isLoading &&
            !provider.hasLocation) {
          return const Scaffold(
            body: FullScreenLoadingOverlay(
              title:
              'Acquiring GPS signal...',
              subtitle:
              'Please wait while we determine your location.',
            ),
          );
        }

        // Fallback location
        final currentLocation =
            provider.currentLocation;

        final mapCenter = currentLocation !=
            null
            ? LatLng(
          currentLocation.latitude,
          currentLocation.longitude,
        )
            : LatLng(
          MapConstants
              .fallbackLatitude,
          MapConstants
              .fallbackLongitude,
        );

        // Auto-follow behavior
        // Auto-follow behavior
        if (provider.autoFollow &&
            provider.isTracking &&
            currentLocation != null) {
          WidgetsBinding.instance
              .addPostFrameCallback((_) {
            _mapController.move(
              mapCenter,
              MapConstants.followZoom,
            );
          });
        }

        return Scaffold(
          appBar: AppBar(
            title: const Text(
              'Live Tracker',
            ),
            actions: [
              IconButton(
                tooltip: provider
                    .autoFollow
                    ? 'Disable Auto Follow'
                    : 'Enable Auto Follow',
                onPressed: provider
                    .toggleAutoFollow,
                icon: Icon(
                  provider.autoFollow
                      ? Icons.gps_fixed
                      : Icons.gps_not_fixed,
                ),
              ),
            ],
          ),

          body: Stack(
            children: [
              // MAP
              FlutterMap(
                mapController:
                _mapController,
                options: MapOptions(
                  initialCenter:
                  mapCenter,
                  initialZoom:
                  MapConstants
                      .defaultZoom,
                  minZoom:
                  MapConstants
                      .minZoom,
                  maxZoom:
                  MapConstants
                      .maxZoom,
                  onPositionChanged: (
                      position,
                      hasGesture,
                      ) {
                    if (hasGesture &&
                        provider
                            .autoFollow) {
                      provider
                          .setAutoFollow(
                        false,
                      );
                    }
                  },
                ),
                children: [
                  // OpenStreetMap tiles
                  TileLayer(
                    urlTemplate:
                    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName:
                    'com.example.tracker',
                  ),

                  // Route history
                  if (provider
                      .history
                      .length >=
                      2)
                    PolylineLayer(
                      polylines: [
                        Polyline(
                          points: provider
                              .history
                              .map(
                                (
                                location,
                                ) =>
                                LatLng(
                                  location
                                      .latitude,
                                  location
                                      .longitude,
                                ),
                          )
                              .toList(),
                          color:
                          MapConstants
                              .routeColor,
                          strokeWidth:
                          MapConstants
                              .routeStrokeWidth,
                        ),
                      ],
                    ),

                  // Start/End markers
                  if (provider
                      .history
                      .isNotEmpty)
                    MarkerLayer(
                      markers: [
                        Marker(
                          point: LatLng(
                            provider
                                .history
                                .first
                                .latitude,
                            provider
                                .history
                                .first
                                .longitude,
                          ),
                          width: 40,
                          height: 40,
                          child:
                          Container(
                            decoration:
                            BoxDecoration(
                              color: Colors
                                  .green,
                              shape: BoxShape
                                  .circle,
                              border:
                              Border
                                  .all(
                                color: Colors
                                    .white,
                                width: 3,
                              ),
                            ),
                            child:
                            const Icon(
                              Icons
                                  .play_arrow,
                              color: Colors
                                  .white,
                            ),
                          ),
                        ),

                        Marker(
                          point: LatLng(
                            provider
                                .history
                                .last
                                .latitude,
                            provider
                                .history
                                .last
                                .longitude,
                          ),
                          width: 40,
                          height: 40,
                          child:
                          Container(
                            decoration:
                            BoxDecoration(
                              color:
                              Colors.red,
                              shape: BoxShape
                                  .circle,
                              border:
                              Border
                                  .all(
                                color: Colors
                                    .white,
                                width: 3,
                              ),
                            ),
                            child:
                            const Icon(
                              Icons.flag,
                              color: Colors
                                  .white,
                            ),
                          ),
                        ),
                      ],
                    ),

                  // Current location marker
                  if (currentLocation !=
                      null)
                    MarkerLayer(
                      markers: [
                        Marker(
                          point:
                          mapCenter,
                          width: 80,
                          height: 80,
                          child:
                          TrackingMarker(
                            location:
                            currentLocation,
                          ),
                        ),
                      ],
                    ),
                ],
              ),

              // Error banner
              if (provider.hasError)
                Positioned(
                  top: 16,
                  left: 16,
                  right: 16,
                  child: Material(
                    elevation: 4,
                    borderRadius:
                    BorderRadius
                        .circular(
                      16,
                    ),
                    color: Colors.red,
                    child: Padding(
                      padding:
                      const EdgeInsets
                          .all(
                        12,
                      ),
                      child: Text(
                        provider
                            .errorMessage ??
                            'Unknown error',
                        style:
                        const TextStyle(
                          color: Colors
                              .white,
                        ),
                      ),
                    ),
                  ),
                ),

              // Recenter button
              // Recenter button
              Positioned(
                right: 16,
                bottom: provider.isTracking
                    ? 320
                    : 100,
                child:
                RecenterButton(
                  autoFollow:
                  provider
                      .autoFollow,
                  onPressed: () {
                    final location =
                        provider
                            .currentLocation;

                    if (location ==
                        null) {
                      return;
                    }

                    provider
                        .setAutoFollow(
                      true,
                    );

                    _mapController
                        .move(
                      LatLng(
                        location
                            .latitude,
                        location
                            .longitude,
                      ),
                      MapConstants
                          .followZoom,
                    );
                  },
                ),
              ),

              // Location information card
              // Location information card
              if (provider.isTracking)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 80,
                  child: LocationInfoCard(
                    location: currentLocation,
                    totalDistanceKm:
                    provider.totalDistanceKm,
                    averageSpeedKmH:
                    provider.averageSpeedKmH,
                    maximumSpeedKmH:
                    provider.maximumSpeedKmH,
                    trackingDuration:
                    provider.trackingDuration,
                    movementType:
                    provider.movementType,
                    isTracking:
                    provider.isTracking,
                  ),
                ),
            ],
          ),

          // Start / Stop controls
          floatingActionButton:
          FloatingActionButton.extended(
            onPressed: () async {
              if (provider
                  .isTracking) {
                await provider
                    .stopTracking();
              } else {
                await provider
                    .startTracking();
              }
            },
            icon: Icon(
              provider.isTracking
                  ? Icons.stop
                  : Icons.play_arrow,
            ),
            label: Text(
              provider.isTracking
                  ? 'Stop'
                  : 'Start',
            ),
          ),
        );
      },
    );
  }
}