import 'package:flutter/material.dart';

import '../../../app/theme.dart';

class DashboardStatsCard extends StatelessWidget {
  final String title;

  final String value;

  final IconData icon;

  final Color color;

  final String? subtitle;

  final VoidCallback? onTap;

  const DashboardStatsCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
    this.subtitle,
    this.onTap,
  });

  @override
  Widget build(
      BuildContext context,
      ) {
    return Material(
      color: Colors.transparent,

      child: InkWell(
        onTap: onTap,

        borderRadius:
        BorderRadius.circular(
          AppTheme.radiusLG,
        ),

        child: Container(
          padding:
          const EdgeInsets.all(
            18,
          ),

          decoration: BoxDecoration(
            color: Colors.white,

            borderRadius:
            BorderRadius.circular(
              AppTheme.radiusLG,
            ),

            boxShadow: [
              BoxShadow(
                color: Colors.black
                    .withOpacity(
                  0.05,
                ),

                blurRadius: 16,

                offset:
                const Offset(
                  0,
                  8,
                ),
              ),
            ],
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .start,

            children: [
              Row(
                children: [
                  Container(
                    width: 52,

                    height: 52,

                    decoration:
                    BoxDecoration(
                      color: color
                          .withOpacity(
                        0.12,
                      ),

                      borderRadius:
                      BorderRadius
                          .circular(
                        16,
                      ),
                    ),

                    child: Icon(
                      icon,

                      color: color,

                      size: 28,
                    ),
                  ),

                  const Spacer(),

                  Icon(
                    Icons
                        .arrow_forward_ios,

                    size: 16,

                    color:
                    Colors.grey
                        .shade400,
                  ),
                ],
              ),

              const SizedBox(
                height: 20,
              ),

              Text(
                value,

                style:
                const TextStyle(
                  fontSize: 28,

                  fontWeight:
                  FontWeight
                      .bold,

                  color: AppTheme
                      .textPrimary,
                ),
              ),

              const SizedBox(
                height: 6,
              ),

              Text(
                title,

                style:
                const TextStyle(
                  fontSize: 14,

                  fontWeight:
                  FontWeight
                      .w600,

                  color: AppTheme
                      .textPrimary,
                ),
              ),

              if (subtitle !=
                  null) ...[
                const SizedBox(
                  height: 4,
                ),

                Text(
                  subtitle!,

                  style:
                  const TextStyle(
                    fontSize:
                    12,

                    color: AppTheme
                        .textSecondary,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}