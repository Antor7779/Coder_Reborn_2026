import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../app/theme.dart';
import '../../models/worker.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/worker_bottom_navigation.dart';
import 'login_screen.dart';
import 'widgets/register_footer_widget.dart';
import 'widgets/register_form_widget.dart';
import 'widgets/register_header_widget.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({
    super.key,
  });

  @override
  State<RegisterScreen> createState() =>
      _RegisterScreenState();
}

class _RegisterScreenState
    extends State<RegisterScreen> {
  final _formKey =
  GlobalKey<FormState>();

  final _fullNameController =
  TextEditingController();

  final _mobileController =
  TextEditingController();

  final _emailController =
  TextEditingController();

  final _addressController =
  TextEditingController();

  final _experienceController =
  TextEditingController();

  final _skillsController =
  TextEditingController();

  final _nidController =
  TextEditingController();

  final _passwordController =
  TextEditingController();

  final _confirmPasswordController =
  TextEditingController();

  String? _selectedTrade;

  @override
  void dispose() {
    _fullNameController.dispose();

    _mobileController.dispose();

    _emailController.dispose();

    _addressController.dispose();

    _experienceController.dispose();

    _skillsController.dispose();

    _nidController.dispose();

    _passwordController.dispose();

    _confirmPasswordController
        .dispose();

    super.dispose();
  }

  Future<void> _register() async {
    if (!_formKey.currentState!
        .validate()) {
      return;
    }

    if (_selectedTrade == null) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(
        const SnackBar(
          content: Text(
            'Please select your trade category.',
          ),
        ),
      );

      return;
    }

    final authProvider =
    context.read<AuthProvider>();

    final worker = Worker(
      id: DateTime.now()
          .millisecondsSinceEpoch,

      fullName:
      _fullNameController.text
          .trim(),

      mobile:
      _mobileController.text
          .trim(),

      email:
      _emailController.text
          .trim(),

      password:
      _passwordController.text,

      address:
      _addressController.text
          .trim(),

      latitude: 0,

      longitude: 0,

      profileImage: '',

      nidNumber:
      _nidController.text
          .trim(),

      nidFrontImage: '',

      nidBackImage: '',

      tradeCategory:
      _selectedTrade!,

      experienceYears:
      int.tryParse(
        _experienceController
            .text,
      ) ??
          0,

      skills:
      _skillsController.text
          .split(',')
          .map(
            (skill) =>
            skill.trim(),
      )
          .where(
            (skill) =>
        skill.isNotEmpty,
      )
          .toList(),

      rating: 5.0,

      totalJobsCompleted: 0,

      points: 0,

      tier: 'Bronze',

      walletBalance: 0,

      bonusBalance: 0,

      isVerified: false,

      faceVerified: false,

      nidVerified: false,

      joinedAt:
      DateTime.now(),
    );

    final registered =
    await authProvider.register(
      worker: worker,
      password:
      _passwordController.text,
    );

    if (!mounted) {
      return;
    }

    if (!registered) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(
        SnackBar(
          content: Text(
            authProvider
                .errorMessage ??
                'Registration failed.',
          ),
          backgroundColor:
          AppTheme.errorColor,
        ),
      );

      return;
    }

    final loggedIn =
    await authProvider.login(
      email:
      _emailController.text
          .trim(),
      password:
      _passwordController.text,
    );

    if (!mounted) {
      return;
    }

    if (loggedIn) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) =>
          const WorkerBottomNavigation(),
        ),
            (route) => false,
      );
    } else {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(
        const SnackBar(
          content: Text(
            'Registration successful. Please login.',
          ),
        ),
      );

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) =>
          const LoginScreen(),
        ),
      );
    }
  }

  @override
  Widget build(
      BuildContext context) {
    final authProvider =
    context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor:
      AppTheme.scaffoldColor,

      body: SafeArea(
        child:
        SingleChildScrollView(
          padding:
          const EdgeInsets.all(
            24,
          ),

          child: Column(
            crossAxisAlignment:
            CrossAxisAlignment
                .stretch,

            children: [
              const RegisterHeaderWidget(),

              RegisterFormWidget(
                formKey: _formKey,

                fullNameController:
                _fullNameController,

                mobileController:
                _mobileController,

                emailController:
                _emailController,

                addressController:
                _addressController,

                experienceController:
                _experienceController,

                skillsController:
                _skillsController,

                nidController:
                _nidController,

                passwordController:
                _passwordController,

                confirmPasswordController:
                _confirmPasswordController,

                selectedTrade:
                _selectedTrade,

                onTradeChanged:
                    (value) {
                  setState(() {
                    _selectedTrade =
                        value;
                  });
                },
              ),

              const SizedBox(
                height: 32,
              ),

              RegisterFooterWidget(
                isLoading:
                authProvider
                    .isLoading,

                onRegister:
                _register,

                onLogin: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                      const LoginScreen(),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}